import pygame
import sys
import random
import math
import os

pygame.init()
info = pygame.display.Info()
display_modes = pygame.display.list_modes(flags=pygame.FULLSCREEN)
wide_modes = [
    mode for mode in (display_modes if isinstance(display_modes, list) else [])
    if abs(mode[0] / mode[1] - 16 / 9) < 0.01
]
if wide_modes:
    WIDTH, HEIGHT = max(wide_modes, key=lambda mode: mode[0] * mode[1])
else:
                                                        
    WIDTH = info.current_w
    HEIGHT = round(WIDTH * 9 / 16)
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)
                                           
WIDTH, HEIGHT = screen.get_size()
pygame.display.set_caption("Survivor Game")
clock  = pygame.time.Clock()

BLACK       = (20,  20,  20)
BLUE        = (50,  120, 255)
GRAY        = (60,  60,  60)
GROUND_COL  = (96,  88,  74)
GROUND_LINE = (58,  52,  40)
STONE_COL_A = (104,  96,  80)
STONE_COL_B = (86,   78,  64)
GROUND_TILE = 100
GOLD        = (255, 210,  60)
WHITE       = (255, 255, 255)
RED         = (255,  60,  60)
GREEN       = (60,  220, 100)
CYAN        = (80,  220, 255)
ORANGE      = (255, 160,  40)
PURPLE      = (180,  80, 255)
YELLOW      = (255, 255,   0)
BOSS_COL    = (160,   0, 160)
BOSS_BORDER = (255, 120, 255)
POTION_COL  = (80,  255, 120)
SWORD_COL   = (200, 230, 255)
SHIELD_COL  = (100, 180, 255)
SLASH_COL   = (220, 240, 255)

ko_candidates = ["malgun.ttf","malgunbd.ttf","NanumGothic.ttf",
                 "NanumBarunGothic.ttf","AppleGothic.ttf","AppleSDGothicNeo.ttc"]
search_dirs   = ["C:/Windows/Fonts/","/usr/share/fonts/",
                 "/System/Library/Fonts/",os.path.expanduser("~/Library/Fonts/")]
font_path = None
for d in search_dirs:
    for f in ko_candidates:
        p = os.path.join(d, f)
        if os.path.exists(p): font_path = p; break
    if font_path: break

def mkfont(size):
    try:    return pygame.font.Font(font_path, size) if font_path else pygame.font.SysFont(None, size)
    except: return pygame.font.SysFont(None, size)

font_hud    = mkfont(36)
font_big    = mkfont(72)
font_banner = mkfont(110)
font_card_t = mkfont(38)
font_card_d = mkfont(28)
font_card_s = mkfont(24)
font_card_xs= mkfont(20)
font_boss   = mkfont(44)

MAP_W = 3000
MAP_H = 3000

P_SIZE        = 50
player_x      = WIDTH  // 2 - P_SIZE // 2
player_y      = HEIGHT // 2 - P_SIZE // 2
player_speed  = 5
player_hp     = 100
player_max_hp = 100
player_damage_numbers = []                        
game_over     = False
world_x = world_y = 0

PLAYER_SCR_CX = player_x + P_SIZE // 2
PLAYER_SCR_CY = player_y + P_SIZE // 2

def pwx(): return -world_x + player_x + P_SIZE // 2
def pwy(): return -world_y + player_y + P_SIZE // 2

def damage_player(dmg):
    global player_hp
    actual_dmg=max(0.0,min(dmg,player_hp))
    if actual_dmg<=0:
        return
    player_hp-=actual_dmg
    now=pygame.time.get_ticks()
    if player_damage_numbers and now-player_damage_numbers[-1][1]<=150:
        player_damage_numbers[-1][0]+=actual_dmg
        player_damage_numbers[-1][1]=now
    else:
        player_damage_numbers.append([actual_dmg,now])

ENEMY_SIZE  = 80
FAST_SIZE   = int(ENEMY_SIZE * 0.7)
MINI_SIZE   = 160
enemies     = []
damage_numbers = []                                                     
enemy_contact_attack_timers = {}                                        

ASSET_DIR = os.path.dirname(__file__)

def load_image(name):
    return pygame.image.load(os.path.join(ASSET_DIR, name)).convert_alpha()

try:
    NORMAL_ENEMY_IMG = pygame.transform.smoothscale(load_image("skeleton_soldier.png"), (ENEMY_SIZE, ENEMY_SIZE))
    FAST_ENEMY_IMG   = pygame.transform.smoothscale(load_image("bat.png"), (FAST_SIZE, FAST_SIZE))
    MINI_ENEMY_IMG   = pygame.transform.smoothscale(load_image("slime.png"), (MINI_SIZE, MINI_SIZE))
except pygame.error:
    NORMAL_ENEMY_IMG = pygame.Surface((ENEMY_SIZE, ENEMY_SIZE), pygame.SRCALPHA)
    NORMAL_ENEMY_IMG.fill((220, 50, 50))
    FAST_ENEMY_IMG   = pygame.Surface((FAST_SIZE, FAST_SIZE), pygame.SRCALPHA)
    FAST_ENEMY_IMG.fill((255, 180, 0))
    MINI_ENEMY_IMG   = pygame.Surface((MINI_SIZE, MINI_SIZE), pygame.SRCALPHA)
    MINI_ENEMY_IMG.fill((180, 0, 180))

try:
    SPLASH_IMG_RAW = load_image("game_start_screen.png")
    SPLASH_IMG = pygame.transform.smoothscale(SPLASH_IMG_RAW, (WIDTH, HEIGHT))
except Exception:
    SPLASH_IMG = None

try:
    MAIN_IMG_RAW = load_image("main_screen.png")
    MAIN_IMG = pygame.transform.smoothscale(MAIN_IMG_RAW, (WIDTH, HEIGHT))
except Exception:
    MAIN_IMG = None

try:
    HIMMEL_IMG_RAW = load_image("himmel.png")
    HIMMEL_IMG = pygame.transform.smoothscale(HIMMEL_IMG_RAW, (180, 180))
except Exception:
    HIMMEL_IMG_RAW = None
    HIMMEL_IMG = None

try:
    HERO_IMG_RAW = load_image("hero.png")
except Exception:
    HERO_IMG_RAW = None

                                                            
try:
    STATUE2_IMG_RAW = load_image("himmel_statue_2.png")
except Exception:
    STATUE2_IMG_RAW = None

try:
    STATUE1_IMG_RAW = load_image("himmel_statue.jpg")
except Exception:
    STATUE1_IMG_RAW = None

def _scale_statue(img_raw):
    if img_raw is None:
        return None
    target_h = int(HEIGHT * 0.75)
    target_w = int(target_h * img_raw.get_width() / img_raw.get_height())
    return pygame.transform.smoothscale(img_raw, (target_w, target_h))

STATUE2_IMG = _scale_statue(STATUE2_IMG_RAW)
STATUE1_IMG = _scale_statue(STATUE1_IMG_RAW)

def _chroma_key(img, bg=(137, 223, 249), tol=38):
    out = img.copy()
    out.lock()
    bg = pygame.Color(*bg)
    for x in range(out.get_width()):
        for y in range(out.get_height()):
            c = out.get_at((x, y))
            dr, dg, db = c.r - bg.r, c.g - bg.g, c.b - bg.b
            if (dr*dr + dg*dg + db*db) ** 0.5 < tol:
                out.set_at((x, y), (c.r, c.g, c.b, 0))
    out.unlock()
    return out

def build_player_sprite(face_img, w=56, h=96):
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    cx = w // 2
    skin     = (250, 224, 196)
    hair     = (151, 196, 226)
    coat     = (232, 222, 196)
    coat_d   = (208, 196, 166)
    pants    = (70,  70,  90)
    boot     = (50,  40,  35)
    stripe_l = (245, 245, 245)
    stripe_d = (60,  95, 150)
    leg_w = 9
    pygame.draw.rect(surf, pants, (cx-leg_w-2, 64, leg_w, 22), border_radius=3)
    pygame.draw.rect(surf, pants, (cx+2,       64, leg_w, 22), border_radius=3)
    pygame.draw.rect(surf, boot,  (cx-leg_w-3, 82, leg_w+2, 11), border_radius=3)
    pygame.draw.rect(surf, boot,  (cx+1,       82, leg_w+2, 11), border_radius=3)
    pygame.draw.rect(surf, coat, (cx-24, 41, 10, 26), border_radius=5)
    pygame.draw.rect(surf, coat, (cx+14, 41, 10, 26), border_radius=5)
    pygame.draw.circle(surf, skin, (cx-19, 68), 5)
    pygame.draw.circle(surf, skin, (cx+19, 68), 5)
    coat_pts = [(cx-12, 36), (cx+12, 36), (cx+20, 70), (cx-20, 70)]
    pygame.draw.polygon(surf, coat, coat_pts)
    pygame.draw.polygon(surf, coat_d, coat_pts, 2)
    collar = pygame.Rect(cx-8, 32, 16, 12)
    pygame.draw.rect(surf, stripe_l, collar, border_radius=2)
    for i, yy in enumerate(range(collar.top, collar.bottom, 3)):
        if i % 2 == 0:
            pygame.draw.rect(surf, stripe_d, (collar.left, yy, collar.w, 2))
    pygame.draw.rect(surf, skin, (cx-5, 28, 10, 8))
    face_size = 40
    if face_img is not None:
        fw, fh = face_img.get_width(), face_img.get_height()
        side = min(int(fw*0.78), fh)
        crop = pygame.Rect((fw-side)//2, 0, side, side)
        face_square = pygame.transform.smoothscale(
            face_img.subsurface(crop), (face_size, face_size)
        ).convert_alpha()
        face_square = _chroma_key(face_square)
        mask = pygame.Surface((face_size, face_size), pygame.SRCALPHA)
        pygame.draw.circle(mask, (255, 255, 255, 255), (face_size//2, face_size//2), face_size//2)
        face_square.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        surf.blit(face_square, (cx-face_size//2, 0))
    else:
        pygame.draw.circle(surf, hair, (cx, 18), face_size//2)
        pygame.draw.circle(surf, skin, (cx, 22), int(face_size*0.4))
    return surf

try:
    FACE_IMG_RAW = load_image("himmel_face.png")
except Exception:
    FACE_IMG_RAW = HIMMEL_IMG_RAW

PLAYER_SPRITE = build_player_sprite(FACE_IMG_RAW)

try:
    HERO_FULL_RAW = load_image("hero_himmel.png")
    HERO_FULL_H = int(HEIGHT * 0.35 * 1.2)
    HERO_FULL_W = int(HERO_FULL_H * HERO_FULL_RAW.get_width() / HERO_FULL_RAW.get_height())
    HERO_FULL_IMG = pygame.transform.smoothscale(HERO_FULL_RAW, (HERO_FULL_W, HERO_FULL_H))
except Exception:
    HERO_FULL_IMG = None

def get_hero_full_pos():
    anchor_x = 0.34
    anchor_y = 0.72
    hx = int(WIDTH * anchor_x) - (HERO_FULL_IMG.get_width() // 2 if HERO_FULL_IMG else 0)
    hy = int(HEIGHT * anchor_y) - (HERO_FULL_IMG.get_height() if HERO_FULL_IMG else 0)
    return hx, hy

screen_state       = "splash"
transition_start   = 0
TRANSITION_DUR     = 800

main_to_game_transition = False
main_to_game_start      = 0
MAIN_TO_GAME_DUR        = 600

                                                              
game_clear        = False
game_clear_time   = 0
             
boss_defeat_particles = []                                                
boss_defeat_flashes   = []                                               
boss_defeat_started   = False
boss_defeat_zoom      = 1.0
boss_defeat_zoom_start= 0

                                          
BOSS_DEFEAT_TOTAL_DUR     = 3000                  
boss_defeat_spawn_schedule = []                                            
boss_defeat_center         = (0, 0)
boss_defeat_gc_alpha       = 0                              

                                                                 
                                

                                                                   
ending_start_time = 0
                 
ENDING_LINES = [
    ("After defeating the Demon King Jiyul", "title"),
    ("", "gap"),
    ("", "gap"),
    ("Peace returned to the world", "body"),
    ("", "gap"),
    ("", "gap"),
    ("To remember him, the people", "body"),
    ("", "gap"),
    ("", "gap"),
    ("erected a statue in the town square", "body"),
    ("", "gap"),
    ("", "gap"),
    ("His name was", "body"),
    ("", "gap"),
    ("", "gap"),
    ("Hero Himmel", "hero"),
    ("", "gap"),
    ("THE END", "end"),
    ("", "gap"),
    ("", "gap"),
    ("", "gap"),
    ("Created by", "sub"),
    ("", "gap"),
    ("", "gap"),
    ("Eunyul Kim", "sub"),
    ("", "gap"),
    ("", "gap"),
    ("Sungwon Jung", "sub"),
]

CREDIT_SCROLL_SPEED = 48                      

def get_ending_font(style):
    if style == "title": return mkfont(42)
    if style == "hero":  return mkfont(64)
    if style == "end":   return mkfont(56)
    if style == "sub":   return mkfont(36)
    return mkfont(34)         

def get_ending_color(style):
    if style == "title": return (200, 200, 200)
    if style == "hero":  return GOLD
    if style == "end":   return WHITE
    if style == "sub":   return (160, 160, 160)
    return (220, 220, 220)

                 
ENDING_LINE_H = []
for txt, sty in ENDING_LINES:
    if txt == "":
        ENDING_LINE_H.append(28)
    else:
        ENDING_LINE_H.append(get_ending_font(sty).get_height() + 8)

ENDING_TOTAL_H = sum(ENDING_LINE_H)

                                                                 
paused = False

PAUSE_BTN_W  = 80
PAUSE_BTN_H  = 40
PAUSE_BTN_X  = WIDTH - PAUSE_BTN_W - 16
PAUSE_BTN_Y  = 12
PAUSE_BTN_R  = pygame.Rect(PAUSE_BTN_X, PAUSE_BTN_Y, PAUSE_BTN_W, PAUSE_BTN_H)

PM_BTN_W = 320
PM_BTN_H = 64
PM_BTN_GAP = 22
PM_BTN_X = WIDTH // 2 - PM_BTN_W // 2

def pm_btn_rect(idx):
    total_h = PM_BTN_H * 3 + PM_BTN_GAP * 2
    top_y   = HEIGHT // 2 - total_h // 2 + 60
    return pygame.Rect(PM_BTN_X, top_y + idx * (PM_BTN_H + PM_BTN_GAP), PM_BTN_W, PM_BTN_H)

PM_LABELS      = ["Continue", "Restart", "Main Menu"]
PM_COLORS      = [(80, 200, 120), (200, 120, 60), (80, 160, 255)]
PM_HOVER_COLS  = [(120, 255, 160), (255, 160, 80), (120, 200, 255)]

def draw_pause_button(mx, my):
    hov = PAUSE_BTN_R.collidepoint(mx, my)
    col = (180, 180, 180) if hov else (100, 100, 100)
    bg  = (50, 50, 60, 200) if not hov else (70, 70, 85, 220)
    bg_surf = pygame.Surface((PAUSE_BTN_W, PAUSE_BTN_H), pygame.SRCALPHA)
    bg_surf.fill(bg)
    screen.blit(bg_surf, (PAUSE_BTN_X, PAUSE_BTN_Y))
    pygame.draw.rect(screen, col, PAUSE_BTN_R, 2, border_radius=8)
    bw, bh = 8, 22
    bx_left  = PAUSE_BTN_X + PAUSE_BTN_W // 2 - bw - 4
    bx_right = PAUSE_BTN_X + PAUSE_BTN_W // 2 + 4
    by_bar   = PAUSE_BTN_Y + (PAUSE_BTN_H - bh) // 2
    pygame.draw.rect(screen, col, (bx_left,  by_bar, bw, bh), border_radius=2)
    pygame.draw.rect(screen, col, (bx_right, by_bar, bw, bh), border_radius=2)

def draw_pause_menu(mx, my):
    ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    ov.fill((0, 0, 0, 170))
    screen.blit(ov, (0, 0))
    panel_w, panel_h = 420, 360
    panel_x = WIDTH  // 2 - panel_w // 2
    panel_y = HEIGHT // 2 - panel_h // 2
    panel_surf = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
    panel_surf.fill((18, 18, 36, 230))
    screen.blit(panel_surf, (panel_x, panel_y))
    pygame.draw.rect(screen, (80, 80, 140), (panel_x, panel_y, panel_w, panel_h), 2, border_radius=14)
    t = font_big.render("Paused", True, GOLD)
    screen.blit(t, (WIDTH // 2 - t.get_width() // 2, panel_y + 24))
    for idx, (label, norm_col, hov_col) in enumerate(zip(PM_LABELS, PM_COLORS, PM_HOVER_COLS)):
        r = pm_btn_rect(idx)
        hov = r.collidepoint(mx, my)
        col = hov_col if hov else norm_col
        btn_surf = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
        btn_surf.fill((*col, 60) if hov else (*col, 30))
        screen.blit(btn_surf, (r.x, r.y))
        pygame.draw.rect(screen, col, r, 2, border_radius=10)
        lbl = font_card_t.render(label, True, WHITE if hov else (200, 200, 200))
        screen.blit(lbl, (r.x + r.w // 2 - lbl.get_width() // 2,
                          r.y + r.h // 2 - lbl.get_height() // 2))

def get_adventure_rect():
    bx = int(WIDTH * 0.655)
    by = int(HEIGHT * 0.66)
    bw = int(WIDTH * 0.285)
    bh = int(HEIGHT * 0.160)
    return pygame.Rect(bx, by, bw, bh)

ADVENTURE_RECT = get_adventure_rect()

def get_portrait_rect():
    px = int(WIDTH * 0.0538)
    py = int(HEIGHT * 0.0510)
    pw = int(WIDTH * 0.0838)
    ph = int(HEIGHT * 0.1403)
    return pygame.Rect(px, py, pw, ph)

def get_name_plate_rect():
    nx = int(WIDTH * 0.1603)
    ny = int(HEIGHT * 0.0787)
    nw = int(WIDTH * 0.2823)
    nh = int(HEIGHT * 0.0935)
    return pygame.Rect(nx, ny, nw, nh)

PORTRAIT_RECT   = get_portrait_rect()
NAME_PLATE_RECT = get_name_plate_rect()

if HIMMEL_IMG_RAW is not None:
    _margin = int(PORTRAIT_RECT.w * 0.1)
    HIMMEL_IMG = pygame.transform.smoothscale(
        HIMMEL_IMG_RAW,
        (PORTRAIT_RECT.w - _margin * 2, PORTRAIT_RECT.h - _margin * 2)
    )

def get_hero_rect():
    hh = int(HEIGHT * 0.60)
    if HERO_IMG_RAW is not None:
        hw = int(hh * HERO_IMG_RAW.get_width() / HERO_IMG_RAW.get_height())
    else:
        hw = int(WIDTH * 0.22)
    hx = int(WIDTH * 0.02)
    hy = int(NAME_PLATE_RECT.bottom + HEIGHT * 0.02)
    return pygame.Rect(hx, hy, hw, hh)

HERO_RECT = get_hero_rect()

if HERO_IMG_RAW is not None:
    HERO_IMG = pygame.transform.smoothscale(HERO_IMG_RAW, (HERO_RECT.w, HERO_RECT.h))
else:
    HERO_IMG = None

shake_timer    = 0
shake_strength = 0.0
shake_ox = shake_oy = 0

def trigger_shake(strength=8, duration=150):
    global shake_timer, shake_strength
    shake_strength = max(shake_strength, float(strength))
    shake_timer    = max(shake_timer, duration)

def update_shake(dt_ms):
    global shake_timer, shake_strength, shake_ox, shake_oy
    if shake_timer > 0:
        shake_timer -= dt_ms
        s = int(shake_strength)
        if s > 0:
            shake_ox = random.randint(-s, s)
            shake_oy = random.randint(-s, s)
        else:
            shake_ox = shake_oy = 0
        if shake_timer <= 0:
            shake_ox = shake_oy = 0
            shake_strength = 0.0
        else:
            shake_strength = max(0.0, shake_strength - shake_strength * (dt_ms / max(shake_timer + dt_ms, 1)) * 1.5)
    else:
        shake_ox = shake_oy = 0
        shake_strength = 0.0

SWORD_BASE_DAMAGE  = 15
SWORD_BASE_RANGE   = 110
SWORD_BASE_ARC     = 90
SWORD_BASE_SPEED   = 1000
SWORD_ANIM_DUR     = 200

sword_damage      = float(SWORD_BASE_DAMAGE)
sword_range       = SWORD_BASE_RANGE
sword_arc         = SWORD_BASE_ARC
sword_cooldown    = SWORD_BASE_SPEED
last_sword_time   = 0
sword_swinging    = False
sword_swing_start = 0
sword_swing_angle = 0.0
sword_hit_ids     = set()
sword_visual_angle = 0.0

boss_bullets    = []
BOSS_BULLET_SPD = 5
BOSS_BULLET_DMG = 8

boss_fire_angle = 0.0
FIRE_INTERVAL   = 150
FIRE_SPEED      = 6.0
boss_beam_warning = None
boss_beams = []
BEAM_WARNING_TIME = 800
BEAM_ACTIVE_TIME = 1400
BEAM_WIDTH = 22
BEAM_DMG = 10
ENRAGE_BEAM_WIDTH_MULT = 2.0
boss_bomb_warning = None
boss_bomb_active = None
BOMB_WARNING_TIME = 900
BOMB_ACTIVE_TIME = 700
BOMB_RADIUS = 220
BOMB_WIDTH = 90
BOMB_DMG = 10
ENRAGE_BOMB_RADIUS_MULT = 1.5
boss_wide_laser_warning = None
boss_wide_laser_active = None
WIDE_LASER_WIDTH = 280
WIDE_LASER_RANGE_MULT = 1.7
WIDE_LASER_DMG = 10
WIDE_LASER_DURATION = 2200
ENRAGE_WIDE_LASER_RANGE_MULT = 1.3
ENRAGE_BOSS_RECT_DMG = 12

BOSS_PATTERN_ORDER = ["beam", "bomb", "wide_laser"]
BOSS_PATTERN_GAP    = 1200
boss_pattern_idx    = 0
boss_pattern_timer  = 0

SHIELD_BASE_COOLDOWN = 10000
SHIELD_DURATION      = 1500
shield_cooldown      = SHIELD_BASE_COOLDOWN
last_shield_time     = -99999
shielding            = False
shield_start_time    = 0

STORM_BASE_CD      = 10000
STORM_BASE_DMG     = 20.0
STORM_DURATION     = 1200
STORM_RADIUS       = 65
storm_cooldown     = STORM_BASE_CD
last_storm_time    = -99999
storm_active       = False
storm_start_time   = 0
storm_angle        = 0.0
storm_hit_set      = set()
storm_hit_timers   = {}

SLASH_BASE_CD      = 10000
SLASH_BASE_DMG     = 40.0
SLASH_BASE_RANGE   = 500
SLASH_BASE_WIDTH   = 60
SLASH_SPEED        = 18
slash_cooldown     = SLASH_BASE_CD
last_slash_time    = -99999
slashes            = []

CHARGE_BASE_CD     = 10000
CHARGE_BASE_DMG    = 40.0
CHARGE_BASE_DIST   = 320
CHARGE_SPEED       = 30
charge_cooldown    = CHARGE_BASE_CD
last_charge_time   = -99999
charging           = False
charge_start_wx    = 0.0
charge_start_wy    = 0.0
charge_angle       = 0.0
charge_dist        = 0.0
charge_max_dist    = CHARGE_BASE_DIST
charge_dmg         = CHARGE_BASE_DMG
charge_hit_ids     = set()

wave            = 1
wave_clear      = False
wave_clear_time = 0
wave_banner_dur = 2000
wave_start_time = 0
showing_banner  = True

SKILL_SHOW_DELAY    = 1000
pending_skill_show  = False
skill_show_time     = 0

MEGA_SIZE        = 320
BOSS_HIT_SIZE    = int(MEGA_SIZE * 0.8)
MEGA_HP_BASE     = 1000
is_boss_wave     = False
mega_boss        = None
boss_shoot_t     = 0
boss_special_t   = 0
boss_spawn_t     = 0
BOSS_SPAWN_INT   = 5000

try:
    boss_surface = load_image("boss_jiyul.png")
    BOSS_IMG = pygame.transform.smoothscale(boss_surface, (MEGA_SIZE, MEGA_SIZE))
except (pygame.error, FileNotFoundError, Exception):
    BOSS_IMG = pygame.Surface((MEGA_SIZE, MEGA_SIZE), pygame.SRCALPHA)
    BOSS_IMG.fill((120, 0, 120))

ENRAGE_MAX_FAST       = 10
ENRAGE_MAX_NORMAL     = 20
ENRAGE_SPAWN_INTERVAL = 2500
enrage_fast_spawned   = 0
enrage_normal_spawned = 0
enrage_last_spawn_t   = 0

BOSS_SHOOT_INTERVAL   = int(3000 / 1.2)
BOSS_SPECIAL_INTERVAL = int(4000 / 1.2)
BOSS_RADIAL_BULLETS   = 15
BOSS_AIM_BULLETS      = 4

boss_laser_active  = None
boss_laser_t       = 0
BOSS_LASER_INTERVAL= 6000
BOSS_LASER_CHARGE  = 1200
BOSS_LASER_FIRE    = 1500
BOSS_LASER_DMG     = 40
BOSS_LASER_W       = 30
BOSS_LASER_RANGE   = 2500

EXPLOSION_DMG         = 28
EXPLOSION_WARNING_TIME = 900

boss_explosion_warnings = []
boss_explosions = []

choosing_skill = False
skill_choices  = []
acquired       = {}

ALL_SKILLS = [
    {"id":"sword_range",  "name":"Longsword", "color":SWORD_COL,
     "desc":"Increase sword range and arc",
     "levels":["Range +25\nArc +15°","Range +55\nArc +30°","Range +90\nArc +50°"]},
    {"id":"sword_speed",  "name":"Quick Slash", "color":(255, 200, 100),
     "desc":"Increase sword attack speed",
     "levels":["Speed +15%","Speed +28%","Speed +40%"]},
    {"id":"atk_up",       "name":"Attack Boost","color":(255, 120, 80),
     "desc":"Increase basic attack damage",
     "levels":["Attack +10","Attack +20","Attack +30"]},
    {"id":"shield",       "name":"Shield",     "color":SHIELD_COL,
     "desc":"Space: 1.5 sec. invulnerability",
     "levels":["Cooldown 10 sec.","Cooldown 9.5 sec.","Cooldown 9 sec.","Cooldown 8.5 sec.","Cooldown 8 sec."]},
    {"id":"storm_atk",    "name":"Storm Attack", "color":(160, 220, 255),
     "desc":"[E] 360° spinning blade attack",
     "levels":["DMG +5/Area +8","DMG +10/Area +16","DMG +15/Area +26","DMG +20/Area +38","DMG +25/Area +52"]},
    {"id":"slash_wave",   "name":"Slash",      "color":(200, 255, 180),
     "desc":"[R] Fire a piercing crescent wave",
     "levels":["CD -0.5 sec.\nDMG +5\nRange +60","CD -1.0 sec.\nDMG +10\nRange +130","CD -1.5 sec.\nDMG +15\nRange +220",
               "CD -2.0 sec.\nDMG +20\nRange +330","CD -2.5 sec.\nDMG +25\nRange +480"]},
    {"id":"charge_atk",   "name":"Storm Charge", "color":(255, 180, 80),
     "desc":"[F] Charge through enemies",
     "levels":["CD -0.5 sec.\nDMG +5\nDistance +60","CD -1.0 sec.\nDMG +10\nDistance +130","CD -1.5 sec.\nDMG +15\nDistance +210",
               "CD -2.0 sec.\nDMG +20\nDistance +300","CD -2.5 sec.\nDMG +25\nDistance +400"]},
]
SKILL_MAP = {s["id"]: s for s in ALL_SKILLS}

AWAKEN_IDS = {"shield", "storm_atk", "slash_wave", "charge_atk"}
awakened   = {}

def slv(sid):  return acquired.get(sid, 0)
def has(sid):  return acquired.get(sid, 0) > 0

def level_value(arr, lv):
    if lv < len(arr): return arr[lv]
    step = arr[-1] - arr[-2] if len(arr) >= 2 else 0
    return arr[-1] + step * (lv - (len(arr) - 1))

def pick_choices():
    pool = []
    for s in ALL_SKILLS:
        lv = acquired.get(s["id"], 0)
        max_lv = len(s["levels"])
        if lv < max_lv: pool.append(s)
        elif lv == max_lv and s["id"] in AWAKEN_IDS and not awakened.get(s["id"]): pool.append(s)
    return random.sample(pool, min(3, len(pool)))

def recalc_sword():
    global sword_damage, sword_range, sword_arc, sword_cooldown
    lv_r = slv("sword_range"); lv_s = slv("sword_speed"); lv_a = slv("atk_up")
    sword_range    = SWORD_BASE_RANGE + [0,25,55,90][lv_r]
    sword_arc      = SWORD_BASE_ARC   + [0,15,30,50][lv_r]
    sword_cooldown = int(SWORD_BASE_SPEED * [1.0,0.85,0.72,0.60][lv_s])
    sword_damage   = SWORD_BASE_DAMAGE + [0,10,20,30][lv_a]

def recalc_shield():
    global shield_cooldown
    lv = slv("shield")
    shield_cooldown = max(5000, SHIELD_BASE_COOLDOWN - (lv-1)*500) if lv>0 else SHIELD_BASE_COOLDOWN

def recalc_active_skills():
    global storm_cooldown, slash_cooldown, charge_cooldown, charge_max_dist, charge_dmg
    lv_st = slv("storm_atk")
    storm_cooldown = max(5000, STORM_BASE_CD - lv_st*500) if lv_st>0 else STORM_BASE_CD
    lv_sl = slv("slash_wave")
    slash_cooldown = max(5000, SLASH_BASE_CD - lv_sl*500)
    lv_ch = slv("charge_atk")
    charge_cooldown = max(5000, CHARGE_BASE_CD - lv_ch*500)
    charge_max_dist = CHARGE_BASE_DIST + level_value([0,60,130,210,300,400], lv_ch)
    charge_dmg      = CHARGE_BASE_DMG + lv_ch * 5

def storm_radius():
    return STORM_RADIUS + level_value([0,8,16,26,38,52], slv("storm_atk"))

def storm_dmg():
    return STORM_BASE_DMG + slv("storm_atk") * 5

def slash_range():
    return SLASH_BASE_RANGE + level_value([0,60,130,220,330,480], slv("slash_wave"))

def slash_dmg():
    return SLASH_BASE_DMG + slv("slash_wave") * 5

def apply_skill(sid):
    max_lv = len(SKILL_MAP[sid]["levels"])
    cur = acquired.get(sid, 0)
    if cur >= max_lv and sid in AWAKEN_IDS and not awakened.get(sid): awakened[sid] = True
    acquired[sid] = cur + 1
    recalc_sword(); recalc_shield(); recalc_active_skills()

def rand_edge():
    side = random.choice(["top","bottom","left","right"])
    if   side=="top":    return float(random.randint(0,MAP_W)), 0.0
    elif side=="bottom": return float(random.randint(0,MAP_W)), float(MAP_H)
    elif side=="left":   return 0.0, float(random.randint(0,MAP_H))
    else:                return float(MAP_W), float(random.randint(0,MAP_H))

NORMAL_BASE_HP   = 50
FAST_BASE_HP     = 30
MINIBOSS_BASE_HP = 200

def enemy_hp_for_wave(base_hp, w):
    tier = (w-1)//3
    return base_hp + tier * max(1, int(base_hp*0.12))

def enemy_count(w):  return max(1, w*2)
def mini_count(w):   return max(1, (1+(w-5)//3+1)//2) if w>=5 else 0
def fast_count(w):   return max(0, (2+(w-3)//2)//2) if w>=3 else 0
def make_enemy(ex, ey, hp, etype): return [float(ex),float(ey),float(hp),float(hp),etype,0.0]

heal_potions = []
POTION_HEAL  = 30
POTION_SIZE  = 20

def spawn_heal_potion():
    heal_potions.append([float(random.randint(MAP_W//5,MAP_W*4//5)),
                         float(random.randint(MAP_H//5,MAP_H*4//5))])

def reset_boss_attack_state():
    global boss_fire_angle, boss_beam_warning, boss_beams
    global boss_bomb_warning, boss_bomb_active
    global boss_wide_laser_warning, boss_wide_laser_active
    global boss_pattern_idx, boss_pattern_timer
    global boss_explosion_warnings, boss_explosions
    boss_fire_angle=0.0; boss_beam_warning=None; boss_beams=[]
    boss_bomb_warning=None; boss_bomb_active=None
    boss_wide_laser_warning=None; boss_wide_laser_active=None
    boss_pattern_idx=0; boss_pattern_timer=0
    boss_explosion_warnings=[]; boss_explosions=[]

def spawn_normal_wave(w):
    global is_boss_wave, mega_boss
    enemies.clear(); boss_bullets.clear(); heal_potions.clear()
    is_boss_wave=False; mega_boss=None
    reset_boss_attack_state()
    n_hp=enemy_hp_for_wave(NORMAL_BASE_HP,w)
    f_hp=enemy_hp_for_wave(FAST_BASE_HP,w)
    m_hp=enemy_hp_for_wave(MINIBOSS_BASE_HP,w)
    for _ in range(enemy_count(w)):
        ex,ey=rand_edge(); enemies.append(make_enemy(ex,ey,n_hp,"normal"))
    for _ in range(mini_count(w)):
        ex,ey=rand_edge(); enemies.append(make_enemy(ex,ey,m_hp,"miniboss"))
    for _ in range(fast_count(w)):
        ex,ey=rand_edge(); enemies.append(make_enemy(ex,ey,f_hp,"fast"))
    if w%3==0: spawn_heal_potion()

def spawn_boss_wave(w):
    global is_boss_wave, mega_boss, boss_shoot_t, boss_special_t, boss_spawn_t
    global boss_laser_t, boss_laser_active
    global enrage_fast_spawned, enrage_normal_spawned, enrage_last_spawn_t
    enemies.clear(); boss_bullets.clear(); heal_potions.clear()
    is_boss_wave=True
    bnum=w//10; max_hp=MEGA_HP_BASE+(bnum-1)*800
    if w>=20: max_hp=int(max_hp*1.5)
    ex=float(MAP_W//2-MEGA_SIZE//2); ey=float(MAP_H//2-MEGA_SIZE//2)
    mega_boss=[ex,ey,float(max_hp),float(max_hp),0,0.0]
    boss_shoot_t=boss_special_t=boss_spawn_t=0
    boss_laser_t=0; boss_laser_active=None
    enrage_fast_spawned=enrage_normal_spawned=0
    reset_boss_attack_state()
    if w%3==0: spawn_heal_potion()

def do_spawn_wave(w):
    if w%10==0: spawn_boss_wave(w)
    else:       spawn_normal_wave(w)

def reset_game_state(ct, spawn_wave=True):
    global player_hp, player_max_hp, game_over, world_x, world_y
    global wave, wave_clear, wave_start_time, choosing_skill, showing_banner
    global pending_skill_show, skill_show_time, skill_choices
    global game_started, paused, main_to_game_transition
    global last_sword_time, sword_swinging, sword_hit_ids
    global last_shield_time, shielding
    global last_storm_time, storm_active
    global last_slash_time, last_charge_time, charging
    global boss_laser_active, enrage_fast_spawned, enrage_normal_spawned
    global game_clear, game_clear_time, boss_defeat_particles, boss_defeat_flashes
    global boss_defeat_started, boss_defeat_zoom, boss_defeat_zoom_start
    global boss_defeat_spawn_schedule, boss_defeat_gc_alpha
    global enemy_contact_attack_timers, damage_numbers, player_damage_numbers

    paused = False
    main_to_game_transition = False
    player_hp = player_max_hp = 100
    enemy_contact_attack_timers.clear()
    damage_numbers.clear()
    player_damage_numbers.clear()
    game_over = False
    game_clear = False
    game_clear_time = 0
    boss_defeat_particles = []
    boss_defeat_flashes = []
    boss_defeat_started = False
    boss_defeat_zoom = 1.0
    boss_defeat_zoom_start = 0
    boss_defeat_spawn_schedule = []
    boss_defeat_gc_alpha = 0
    world_x = world_y = 0
    wave = 1
    wave_clear = False
    choosing_skill = False
    showing_banner = True
    pending_skill_show = False
    skill_show_time = 0
    skill_choices = []
    acquired.clear()
    awakened.clear()
    recalc_sword()
    recalc_shield()
    recalc_active_skills()
    last_sword_time = 0
    sword_swinging = False
    sword_hit_ids = set()
    last_shield_time = -99999
    shielding = False
    last_storm_time = -99999
    storm_active = False
    last_slash_time = -99999
    slashes.clear()
    last_charge_time = -99999
    charging = False
    boss_bullets.clear()
    heal_potions.clear()
    boss_laser_active = None
    enrage_fast_spawned = enrage_normal_spawned = 0
    reset_boss_attack_state()

    if spawn_wave:
        do_spawn_wave(wave)
        wave_start_time = ct
        game_started = True
    else:
        enemies.clear()
        game_started = False

                                                                 
RETRO_PALETTE = [
    (255, 255,  80),       
    (255, 180,  30),       
    (255,  80,  80),       
    (255, 255, 255),       
    (80,  255, 200),       
    (200, 100, 255),       
]

def start_boss_defeat_effect(bx, by, ct):
    """Called when a boss dies. Schedules explosions and flashes to appear over 3 seconds.
    Particles and flashes are spawned in sequence during update."""
    global boss_defeat_particles, boss_defeat_flashes, boss_defeat_started
    global boss_defeat_zoom_start, boss_defeat_spawn_schedule, boss_defeat_center
    global boss_defeat_gc_alpha

    boss_defeat_started = True
    boss_defeat_zoom_start = ct
    boss_defeat_gc_alpha = 0
    boss_defeat_particles = []
    boss_defeat_flashes = []

                                             
    scr_bx = int(bx + world_x)
    scr_by = int(by + world_y)
    cx = scr_bx + MEGA_SIZE // 2
    cy = scr_by + MEGA_SIZE // 2
    boss_defeat_center = (cx, cy)

                                                 
    boss_defeat_spawn_schedule = []

                                         
    flash_radii = [80, 160, 260, 380]
    for i, r in enumerate(flash_radii):
        t_off = 200 + i * 550                                         
        boss_defeat_spawn_schedule.append((t_off, "flash", r))

                                               
    PARTICLE_TOTAL  = 120
    PARTICLE_WAVES  = 14                                
    per_wave = max(1, PARTICLE_TOTAL // PARTICLE_WAVES)
    spawned_so_far = 0
    for w_i in range(PARTICLE_WAVES):
        t_off = int(100 + w_i * (2600 / PARTICLE_WAVES))
        if w_i < PARTICLE_WAVES - 1:
            count = per_wave
        else:
            count = PARTICLE_TOTAL - spawned_so_far
        boss_defeat_spawn_schedule.append((t_off, "particles", count))
        spawned_so_far += count

    boss_defeat_spawn_schedule.sort(key=lambda x: x[0])

def _spawn_defeat_particles(cx, cy, count):
    for _ in range(count):
        angle = random.uniform(0, 2*math.pi)
        speed = random.uniform(2, 14)
        vx = math.cos(angle) * speed
        vy = math.sin(angle) * speed
        size = random.randint(4, 18)
        col = random.choice(RETRO_PALETTE)
        life = random.randint(40, 90)
        boss_defeat_particles.append([cx, cy, vx, vy, size, col, life, life])

def update_boss_defeat(dt_ms, ct):
    global boss_defeat_zoom, boss_defeat_particles, boss_defeat_flashes
    global game_clear, game_clear_time, screen_state
    global boss_defeat_spawn_schedule, boss_defeat_gc_alpha

    elapsed = ct - boss_defeat_zoom_start
    cx, cy = boss_defeat_center

                                                
    while boss_defeat_spawn_schedule and boss_defeat_spawn_schedule[0][0] <= elapsed:
        t_off, kind, payload = boss_defeat_spawn_schedule.pop(0)
        if kind == "flash":
            r = payload
            boss_defeat_flashes.append([cx, cy, 0, r, 30, 30])
        elif kind == "particles":
            _spawn_defeat_particles(cx, cy, payload)

              
    for p in boss_defeat_particles[:]:
        p[0] += p[2]; p[1] += p[3]
        p[3] += 0.3      
        p[6] -= 1
        if p[6] <= 0:
            boss_defeat_particles.remove(p)

              
    for f in boss_defeat_flashes[:]:
        f[2] += (f[3] - f[2]) * 0.18
        f[4] -= 1
        if f[4] <= 0:
            boss_defeat_flashes.remove(f)

                                                      
    zoom_dur = BOSS_DEFEAT_TOTAL_DUR
    if elapsed < zoom_dur:
        prog = elapsed / zoom_dur
        eased = 1.0 - (1.0 - prog) ** 2                   
        boss_defeat_zoom = 1.0 + eased * 0.08
    else:
        boss_defeat_zoom = 1.08

                                                   
    GC_FADE_START = BOSS_DEFEAT_TOTAL_DUR - 1000
    if elapsed >= GC_FADE_START:
        fade_prog = min(1.0, (elapsed - GC_FADE_START) / 1000.0)
        boss_defeat_gc_alpha = int(255 * fade_prog)
    else:
        boss_defeat_gc_alpha = 0

                                                      
                                              
    if elapsed >= BOSS_DEFEAT_TOTAL_DUR and not game_clear:
        game_clear = True
        game_clear_time = ct

def draw_boss_defeat_effect():
                                     
    for f in boss_defeat_flashes:
        cx2, cy2, r_now, r_max, life, max_life = f
        alpha = int(255 * life / max_life)
        ring_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        pygame.draw.circle(ring_surf, (255, 240, 100, alpha), (int(cx2), int(cy2)), int(r_now), 8)
        pygame.draw.circle(ring_surf, (255, 255, 255, alpha//2), (int(cx2), int(cy2)), int(r_now*0.6), 4)
        screen.blit(ring_surf, (0, 0))
                      
    for p in boss_defeat_particles:
        px2, py2, vx, vy, size, col, life, max_life = p
        alpha = int(255 * life / max_life)
                        
        psurf = pygame.Surface((size, size), pygame.SRCALPHA)
        psurf.fill((*col, alpha))
        screen.blit(psurf, (int(px2 - size//2), int(py2 - size//2)))
                  
        if size > 8:
            inner = size // 2
            isurf = pygame.Surface((inner, inner), pygame.SRCALPHA)
            isurf.fill((255, 255, 255, alpha // 2))
            screen.blit(isurf, (int(px2 - inner//2), int(py2 - inner//2)))

                                                    
                                           
    if boss_defeat_gc_alpha > 0:
        gc_font = mkfont(120)
        label = "GAME CLEAR"
        colors_shadow = [(80,0,0),(140,40,0),(200,100,0)]
        for i, sc in enumerate(colors_shadow):
            off = (i+1)*4
            ts = gc_font.render(label, True, sc)
            ts.set_alpha(boss_defeat_gc_alpha)
            screen.blit(ts, (WIDTH//2 - ts.get_width()//2 + off, HEIGHT//2 - 80 + off))
        t_main = gc_font.render(label, True, GOLD)
        t_main.set_alpha(boss_defeat_gc_alpha)
        screen.blit(t_main, (WIDTH//2 - t_main.get_width()//2, HEIGHT//2 - 80))

                                                                   
ending_credit_y  = 0.0                         
ending_scroll_done = False

def reset_ending():
    global ending_start_time, ending_credit_y, ending_scroll_done
    ending_start_time = pygame.time.get_ticks()
    ending_credit_y = float(HEIGHT)
    ending_scroll_done = False

def get_ending_main_button_rect():
    return pygame.Rect(24, HEIGHT - 88, 280, 56)

def draw_ending(ct, dt, mx, my):
    global ending_credit_y, ending_scroll_done
    screen.fill((0, 0, 0))

    elapsed = (ct - ending_start_time) / 1000.0           

                                                                 
    left_w = WIDTH // 2 - 40
    img_x  = 40

                                                              
                                                                            
    statue_surf = None
    statue_alpha = 0

    if elapsed < 3.0:
        statue_alpha = 0
    elif elapsed < 6.0:
                         
        fade = (elapsed - 3.0) / 3.0
        statue_alpha = int(fade * 255)
        statue_surf = STATUE2_IMG
    elif elapsed < 13.5:
        statue_alpha = 255
        statue_surf = STATUE1_IMG
    elif elapsed < 21.0:
                  
        fade = 1.0 - (elapsed - 13.5) / 7.5
        statue_alpha = int(fade * 255)
        statue_surf = STATUE1_IMG
    else:
        statue_alpha = 0

    if statue_surf is not None and statue_alpha > 0:
                       
        sw = statue_surf.get_width()
        sh = statue_surf.get_height()
                      
        scale = min(left_w / sw, (HEIGHT - 80) / sh)
        draw_w = int(sw * scale)
        draw_h = int(sh * scale)
        draw_y = (HEIGHT - draw_h) // 2
        tmp = pygame.transform.smoothscale(statue_surf, (draw_w, draw_h))
        tmp.set_alpha(statue_alpha)
        screen.blit(tmp, (img_x + (left_w - draw_w) // 2, draw_y))

            
    pygame.draw.line(screen, (60, 60, 80), (WIDTH//2 - 20, 60), (WIDTH//2 - 20, HEIGHT - 60), 1)

                                                               
    right_x = WIDTH // 2 + 20
    right_w = WIDTH // 2 - 60

              
    if not ending_scroll_done:
        ending_credit_y -= CREDIT_SCROLL_SPEED * dt
                               
        if ending_credit_y + ENDING_TOTAL_H < -40:
            ending_scroll_done = True

                    
    clip_rect = pygame.Rect(right_x - 10, 40, right_w + 10, HEIGHT - 80)
    screen.set_clip(clip_rect)

    cy = int(ending_credit_y)
    for i, (txt, sty) in enumerate(ENDING_LINES):
        lh = ENDING_LINE_H[i]
        if txt:
            f = get_ending_font(sty)
            col = get_ending_color(sty)
                                
            if 40 <= cy <= HEIGHT + 10 or 40 <= cy + lh <= HEIGHT:
                surf_t = f.render(txt, True, col)
                tx = right_x + (right_w - surf_t.get_width()) // 2
                                              
                if sty in ("hero", "end"):
                    glow = mkfont(get_ending_font(sty).size(txt[0])[1] if txt else 40)
                    for gd in [(2, 2), (-2, 2), (2, -2), (-2, -2)]:
                        gs = f.render(txt, True, (80,60,20) if sty=="hero" else (40,40,80))
                        screen.blit(gs, (tx+gd[0], cy+gd[1]))
                screen.blit(surf_t, (tx, cy))
        cy += lh

    screen.set_clip(None)

                                                        
    btn_r = get_ending_main_button_rect()
    hov = btn_r.collidepoint(mx, my)
    col_b = (120, 200, 255) if hov else (60, 120, 200)
    bs = pygame.Surface((btn_r.width, btn_r.height), pygame.SRCALPHA)
    bs.fill((*col_b, 90 if hov else 60))
    screen.blit(bs, btn_r.topleft)
    pygame.draw.rect(screen, col_b, btn_r, 2, border_radius=10)
    bl = mkfont(30).render("Return to Main Menu", True, WHITE if hov else (180,180,200))
    screen.blit(bl, (btn_r.centerx - bl.get_width()//2, btn_r.centery - bl.get_height()//2))
    return btn_r

CARD_W, CARD_H = 260, 330
CARD_GAP       = 30
CARD_X0        = (WIDTH-(CARD_W*3+CARD_GAP*2))//2
CARD_Y0        = (HEIGHT-CARD_H)//2

MINI_MAP_W  = 160
MINI_MAP_H  = 160
MINI_MAP_X  = WIDTH-MINI_MAP_W-30
MINI_MAP_Y  = 140

def draw_minimap():
    mm_surf=pygame.Surface((MINI_MAP_W,MINI_MAP_H),pygame.SRCALPHA)
    mm_surf.fill((0,0,0,160))
    pygame.draw.rect(mm_surf,(80,80,80,200),(0,0,MINI_MAP_W,MINI_MAP_H),1)
    def to_mini(wx,wy):
        return int(wx/MAP_W*MINI_MAP_W), int(wy/MAP_H*MINI_MAP_H)
    for e in enemies:
        mx2,my2=to_mini(e[0],e[1])
        col=(255,80,255) if e[4]=="miniboss" else ((255,200,0) if e[4]=="fast" else (220,60,60))
        r=4 if e[4]=="miniboss" else 2
        pygame.draw.circle(mm_surf,col,(mx2,my2),r)
    if mega_boss:
        bmmx,bmmy=to_mini(mega_boss[0]+MEGA_SIZE//2,mega_boss[1]+MEGA_SIZE//2)
        pygame.draw.circle(mm_surf,(255,0,255),(bmmx,bmmy),6)
        pygame.draw.circle(mm_surf,(255,120,255),(bmmx,bmmy),6,2)
    for pot in heal_potions:
        pmx2,pmy2=to_mini(pot[0],pot[1])
        pmx2=max(3,min(MINI_MAP_W-3,pmx2)); pmy2=max(3,min(MINI_MAP_H-3,pmy2))
        pygame.draw.line(mm_surf,POTION_COL,(pmx2,pmy2-4),(pmx2,pmy2+4),2)
        pygame.draw.line(mm_surf,POTION_COL,(pmx2-4,pmy2),(pmx2+4,pmy2),2)
        pygame.draw.circle(mm_surf,(150,255,180),(pmx2,pmy2),3)
    pmx,pmy=to_mini(pwx(),pwy())
    pmx=max(3,min(MINI_MAP_W-3,pmx)); pmy=max(3,min(MINI_MAP_H-3,pmy))
    pygame.draw.circle(mm_surf,BLUE,(pmx,pmy),4)
    pygame.draw.circle(mm_surf,WHITE,(pmx,pmy),4,1)
    screen.blit(mm_surf,(MINI_MAP_X,MINI_MAP_Y))
    pygame.draw.rect(screen,(100,100,100),(MINI_MAP_X,MINI_MAP_Y,MINI_MAP_W,MINI_MAP_H),1)

def draw_skill_ui(mx, my):
    ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
    ov.fill((0,0,0,210)); screen.blit(ov,(0,0))
    t=font_big.render("-- LEVEL UP! --",True,GOLD)
    screen.blit(t,(WIDTH//2-t.get_width()//2,CARD_Y0-120))
    sub=font_card_d.render("Choose a skill",True,(180,180,180))
    screen.blit(sub,(WIDTH//2-sub.get_width()//2,CARD_Y0-44))
    for i,sk in enumerate(skill_choices):
        cx=CARD_X0+i*(CARD_W+CARD_GAP); cy=CARD_Y0
        rect=pygame.Rect(cx,cy,CARD_W,CARD_H)
        hov=rect.collidepoint(mx,my); lv=slv(sk["id"])
        surf=pygame.Surface((CARD_W,CARD_H),pygame.SRCALPHA)
        surf.fill((35,35,65,240) if hov else (20,20,42,215))
        screen.blit(surf,(cx,cy))
        pygame.draw.rect(screen,sk["color"] if hov else (70,70,110),rect,3 if hov else 1,border_radius=10)
        icx,icy=cx+CARD_W//2,cy+52
        pygame.draw.circle(screen,sk["color"],(icx,icy),32)
        ic=mkfont(36).render(sk["name"][0],True,BLACK)
        screen.blit(ic,(icx-ic.get_width()//2,icy-ic.get_height()//2))
        nt=font_card_t.render(sk["name"],True,sk["color"] if hov else WHITE)
        screen.blit(nt,(cx+CARD_W//2-nt.get_width()//2,cy+92))
        max_lv=len(sk["levels"])
        if lv>=max_lv: lv_str=f"Lv{lv} -> Awakened!"; ne_lines=["-> Awakened: Bonus effect enhanced"]
        else:
            lv_str=f"Lv{lv} -> {lv+1}" if lv>0 else "New Skill"
            ne_lines=["-> "+l for l in sk["levels"][lv].split("\n")]
        ls=font_card_s.render(lv_str,True,GOLD if lv>0 else (150,150,150))
        screen.blit(ls,(cx+CARD_W//2-ls.get_width()//2,cy+132))
        desc_y=cy+158
        for line in ne_lines:
            line_surf=font_card_xs.render(line,True,(150,220,255))
            if line_surf.get_width()>CARD_W-16:
                clip_surf=pygame.Surface((CARD_W-16,line_surf.get_height()),pygame.SRCALPHA)
                clip_surf.blit(line_surf,(0,0)); line_surf=clip_surf
            screen.blit(line_surf,(cx+(CARD_W-min(line_surf.get_width(),CARD_W-16))//2,desc_y))
            desc_y+=line_surf.get_height()+2
            if desc_y>cy+CARD_H-50: break
        max_txt=font_card_s.render(f"Max Level: {max_lv}",True,(100,100,140))
        screen.blit(max_txt,(cx+CARD_W//2-max_txt.get_width()//2,cy+CARD_H-46))
        if hov:
            hi=font_card_s.render("Click to Select",True,GOLD)
            screen.blit(hi,(cx+CARD_W//2-hi.get_width()//2,cy+CARD_H-24))

def draw_splash(ct):
    screen.fill(BLACK)
    if SPLASH_IMG: screen.blit(SPLASH_IMG,(0,0))
    alpha_ts=int(abs(math.sin(ct*0.002))*180)+30
    ts=mkfont(48).render("Touch to Start",True,WHITE)
    ts.set_alpha(alpha_ts)
    screen.blit(ts,(WIDTH//2-ts.get_width()//2,HEIGHT-120))

def draw_transition(ct):
    elapsed=ct-transition_start; prog=min(1.0,elapsed/TRANSITION_DUR)
    scale=1.0+prog*0.08
    if SPLASH_IMG:
        sw=int(WIDTH*scale); sh=int(HEIGHT*scale)
        scaled=pygame.transform.smoothscale(SPLASH_IMG,(sw,sh))
        screen.blit(scaled,((WIDTH-sw)//2,(HEIGHT-sh)//2))
    else: screen.fill(BLACK)
    fade_surf=pygame.Surface((WIDTH,HEIGHT)); fade_surf.fill((10,5,20))
    fade_surf.set_alpha(int(prog*230)); screen.blit(fade_surf,(0,0))

def draw_main_to_game_transition(ct):
    elapsed=ct-main_to_game_start; prog=min(1.0,elapsed/MAIN_TO_GAME_DUR)
    eased=1.0-(1.0-prog)**2; scale=1.0+eased*0.12
    if MAIN_IMG:
        sw=int(WIDTH*scale); sh=int(HEIGHT*scale)
        scaled=pygame.transform.smoothscale(MAIN_IMG,(sw,sh))
        screen.blit(scaled,((WIDTH-sw)//2,(HEIGHT-sh)//2))
    else: screen.fill(BLACK)
    fade=pygame.Surface((WIDTH,HEIGHT)); fade.fill((5,5,15))
    fade.set_alpha(int(eased*255)); screen.blit(fade,(0,0))

def draw_main(mx, my):
    screen.fill(BLACK)
    if MAIN_IMG: screen.blit(MAIN_IMG,(0,0))
    if HERO_FULL_IMG is not None:
        hx,hy=get_hero_full_pos(); screen.blit(HERO_FULL_IMG,(hx,hy))
    else:
        t=font_big.render("Main Menu",True,GOLD)
        screen.blit(t,(WIDTH//2-t.get_width()//2,HEIGHT//2-40))
    if HIMMEL_IMG:
        margin=(PORTRAIT_RECT.w-HIMMEL_IMG.get_width())//2
        screen.blit(HIMMEL_IMG,(PORTRAIT_RECT.x+margin,PORTRAIT_RECT.y+margin))
    if HERO_IMG: screen.blit(HERO_IMG,(HERO_RECT.x,HERO_RECT.y))
    name_txt=font_card_t.render("Hero Himmel",True,(50,30,15))
    screen.blit(name_txt,(NAME_PLATE_RECT.x+(NAME_PLATE_RECT.w-name_txt.get_width())//2,
                           NAME_PLATE_RECT.y+(NAME_PLATE_RECT.h-name_txt.get_height())//2))
    if ADVENTURE_RECT.collidepoint(mx,my):
        hover_surf=pygame.Surface((ADVENTURE_RECT.w,ADVENTURE_RECT.h),pygame.SRCALPHA)
        hover_surf.fill((255,220,100,40)); screen.blit(hover_surf,(ADVENTURE_RECT.x,ADVENTURE_RECT.y))

running     = True
game_started= False

                       
boss_10_cleared = False

while running:
    clock.tick(60)

    ct     = pygame.time.get_ticks()
    keys   = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    dt_ms  = clock.get_time()
    dt     = dt_ms / 1000.0

             
    if screen_state == "splash":
        for event in pygame.event.get():
            if event.type == pygame.QUIT: running=False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: running=False
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                screen_state="transition"; transition_start=ct
        draw_splash(ct); pygame.display.update(); continue

           
    if screen_state == "transition":
        for event in pygame.event.get():
            if event.type == pygame.QUIT: running=False
        draw_transition(ct); pygame.display.update()
        if ct-transition_start>=TRANSITION_DUR: screen_state="main"
        continue

                    
    if screen_state == "main_to_game":
        for event in pygame.event.get():
            if event.type == pygame.QUIT: running=False
        draw_main_to_game_transition(ct)
        pygame.display.update()
        if ct-main_to_game_start>=MAIN_TO_GAME_DUR: screen_state="game"
        continue

           
    if screen_state == "main":
        for event in pygame.event.get():
            if event.type == pygame.QUIT: running=False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: running=False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button==1:
                if ADVENTURE_RECT.collidepoint(mx,my):
                    reset_game_state(ct, spawn_wave=True)
                    boss_10_cleared = False
                    main_to_game_transition=True; main_to_game_start=ct
                    screen_state="main_to_game"
        draw_main(mx,my); pygame.display.update(); continue

                  
                                             
                                               
                                             
                 
    if screen_state == "game_clear":
        for event in pygame.event.get():
            if event.type == pygame.QUIT: running=False
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                reset_ending()
                screen_state = "ending"

                                                       
        game_surf = pygame.Surface((WIDTH, HEIGHT))
        game_surf.fill(GROUND_COL)
        screen.blit(game_surf, (0, 0))

        boss_defeat_gc_alpha = 255
        draw_boss_defeat_effect()

                     
        end_alpha = int(abs(math.sin(ct * 0.0025)) * 160) + 60
        hint = mkfont(30).render("Tap or click the screen", True, (220, 220, 255))
        hint.set_alpha(end_alpha)
        screen.blit(hint, (WIDTH//2 - hint.get_width()//2, HEIGHT//2 + 90))

        pygame.display.update()
        continue

              
    if screen_state == "ending":
        main_btn = get_ending_main_button_rect()
        for event in pygame.event.get():
            if event.type == pygame.QUIT: running=False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if main_btn and main_btn.collidepoint(mx, my):
                    reset_game_state(ct, spawn_wave=False)
                    boss_10_cleared = False
                    screen_state = "main"
        main_btn = draw_ending(ct, dt, mx, my)
        pygame.display.update()
        continue

                                                                     
           
                                                                     
    px=pwx(); py=pwy()

    if not paused:
        update_shake(dt_ms)

                                       
    if boss_defeat_started and not game_clear:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: running=False
        update_boss_defeat(dt_ms, ct)
                             
        game_surf = pygame.Surface((WIDTH, HEIGHT))
        game_surf.fill(GROUND_COL)
        ox2=shake_ox; oy2=shake_oy
        vis_x0=max(0,int((-world_x-ox2)//GROUND_TILE)*GROUND_TILE-GROUND_TILE)
        vis_x1=min(MAP_W,vis_x0+WIDTH+GROUND_TILE*3)
        vis_y0=max(0,int((-world_y-oy2)//GROUND_TILE)*GROUND_TILE-GROUND_TILE)
        vis_y1=min(MAP_H,vis_y0+HEIGHT+GROUND_TILE*3)
        for gx in range(vis_x0,vis_x1,GROUND_TILE):
            for gy in range(vis_y0,vis_y1,GROUND_TILE):
                stone_col=STONE_COL_A if (gx//GROUND_TILE+gy//GROUND_TILE)%2==0 else STONE_COL_B
                pygame.draw.rect(game_surf,stone_col,(gx+world_x+ox2,gy+world_y+oy2,GROUND_TILE,GROUND_TILE))
        screen.blit(game_surf, (0,0))
                           
        if boss_defeat_zoom > 1.0:
            zw = int(WIDTH * boss_defeat_zoom)
            zh = int(HEIGHT * boss_defeat_zoom)
            zoomed = pygame.transform.smoothscale(screen.copy(), (zw, zh))
            screen.blit(zoomed, ((WIDTH-zw)//2, (HEIGHT-zh)//2))
        draw_boss_defeat_effect()
        if game_clear:
            screen_state = "game_clear"
        pygame.display.update()
        continue

               
    for event in pygame.event.get():
        if event.type == pygame.QUIT: running=False

        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_p) and not game_over and not choosing_skill:
                paused = not paused

        if event.type == pygame.MOUSEBUTTONDOWN and event.button==1:
            if paused:
                for idx in range(3):
                    if pm_btn_rect(idx).collidepoint(mx,my):
                        if idx == 0:
                            paused = False
                        elif idx == 1:
                            reset_game_state(ct, spawn_wave=True)
                            boss_10_cleared = False
                        elif idx == 2:
                            reset_game_state(ct, spawn_wave=False)
                            boss_10_cleared = False
                            screen_state="main"
                        break
                if PAUSE_BTN_R.collidepoint(mx,my):
                    paused = False
            else:
                if PAUSE_BTN_R.collidepoint(mx,my) and not game_over and not choosing_skill:
                    paused = True
                elif choosing_skill:
                    for i,sk in enumerate(skill_choices):
                        rect=pygame.Rect(CARD_X0+i*(CARD_W+CARD_GAP),CARD_Y0,CARD_W,CARD_H)
                        if rect.collidepoint(mx,my):
                            apply_skill(sk["id"])
                            choosing_skill=False
                            wave+=1; wave_clear=False; showing_banner=True
                            pending_skill_show=False
                            do_spawn_wave(wave); wave_start_time=ct
                            break
                elif not game_over:
                    if ct-last_sword_time>=sword_cooldown and not sword_swinging:
                        angle=math.atan2(my-PLAYER_SCR_CY,mx-PLAYER_SCR_CX)
                        sword_swing_angle=angle
                        sword_visual_angle=angle-math.radians(sword_arc/2)
                        sword_swinging=True; sword_swing_start=ct
                        last_sword_time=ct; sword_hit_ids=set()

        if event.type == pygame.KEYDOWN and not paused and not game_over and not choosing_skill:
            if event.key==pygame.K_SPACE:
                if has("shield") and ct-last_shield_time>=shield_cooldown and not shielding:
                    shielding=True; shield_start_time=ct; last_shield_time=ct
            if event.key==pygame.K_e:
                if has("storm_atk") and ct-last_storm_time>=storm_cooldown and not storm_active:
                    storm_active=True; storm_start_time=ct; last_storm_time=ct
                    storm_angle=0.0; storm_hit_timers={}
            if event.key==pygame.K_r:
                if has("slash_wave") and ct-last_slash_time>=slash_cooldown:
                    aim=math.atan2(my-PLAYER_SCR_CY,mx-PLAYER_SCR_CX)
                    slashes.append([float(px),float(py),aim,0.0,
                                    slash_range(),slash_dmg(),
                                    SLASH_BASE_WIDTH+slv("slash_wave")*8,set()])
                    last_slash_time=ct
            if event.key==pygame.K_f:
                if has("charge_atk") and ct-last_charge_time>=charge_cooldown and not charging:
                    aim=math.atan2(my-PLAYER_SCR_CY,mx-PLAYER_SCR_CX)
                    charge_angle=aim; charge_dist=0.0
                    charge_start_wx=world_x; charge_start_wy=world_y
                    charging=True; last_charge_time=ct; charge_hit_ids=set()

    if paused:
        draw_pause_menu(mx, my)
        pygame.display.update()
        continue

    if shielding and ct-shield_start_time>=SHIELD_DURATION: shielding=False
    if storm_active and ct-storm_start_time>=STORM_DURATION: storm_active=False

              
    if game_over:
        screen.fill(BLACK)
        t1=font_banner.render("GAME OVER",True,RED)
        screen.blit(t1,(WIDTH//2-t1.get_width()//2,HEIGHT//2-190))
        t2=font_big.render(f"Survived {wave} waves",True,GOLD)
        screen.blit(t2,(WIDTH//2-t2.get_width()//2,HEIGHT//2-80))
        sk_str="  /  ".join(f"{SKILL_MAP[sid]['name']} Lv{lv}" for sid,lv in acquired.items()) or "None"
        t3=font_card_d.render(f"Skills acquired: {sk_str}",True,(180,180,180))
        screen.blit(t3,(WIDTH//2-t3.get_width()//2,HEIGHT//2+10))
        t4=font_card_d.render("R: Restart",True,WHITE)
        screen.blit(t4,(WIDTH//2-t4.get_width()//2,HEIGHT//2+60))
        t5=font_card_d.render("M: Return to Main Menu",True,CYAN)
        screen.blit(t5,(WIDTH//2-t5.get_width()//2,HEIGHT//2+105))
        pygame.display.update()

        def full_reset():
            global player_hp,player_max_hp,game_over,world_x,world_y
            global wave,wave_clear,choosing_skill,showing_banner,pending_skill_show
            global last_sword_time,sword_swinging,sword_hit_ids
            global last_shield_time,shielding,last_storm_time,storm_active
            global last_slash_time,last_charge_time,charging
            global boss_laser_active,enrage_fast_spawned,enrage_normal_spawned
            global boss_defeat_particles,boss_defeat_flashes,boss_defeat_started
            global boss_defeat_zoom,game_clear,boss_10_cleared
            global boss_defeat_spawn_schedule,boss_defeat_gc_alpha
            global enemy_contact_attack_timers,damage_numbers,player_damage_numbers
            player_hp=player_max_hp=100; game_over=False; world_x=world_y=0
            enemy_contact_attack_timers.clear(); damage_numbers.clear()
            player_damage_numbers.clear()
            wave=1; wave_clear=choosing_skill=False; showing_banner=True; pending_skill_show=False
            acquired.clear(); awakened.clear()
            recalc_sword(); recalc_shield(); recalc_active_skills()
            last_sword_time=0; sword_swinging=False; sword_hit_ids=set()
            last_shield_time=-99999; shielding=False
            last_storm_time=-99999; storm_active=False
            last_slash_time=-99999; slashes.clear()
            last_charge_time=-99999; charging=False
            boss_bullets.clear(); heal_potions.clear()
            boss_laser_active=None; enrage_fast_spawned=enrage_normal_spawned=0
            reset_boss_attack_state()
            boss_defeat_particles=[]; boss_defeat_flashes=[]; boss_defeat_started=False
            boss_defeat_zoom=1.0; game_clear=False; boss_10_cleared=False
            boss_defeat_spawn_schedule=[]; boss_defeat_gc_alpha=0

        if keys[pygame.K_r]:
            full_reset(); do_spawn_wave(wave); wave_start_time=ct
        elif keys[pygame.K_m]:
            full_reset(); enemies.clear(); game_started=False; screen_state="main"
        continue

    if choosing_skill:
        draw_skill_ui(mx,my); pygame.display.update(); continue

                                                              
    boss_dead  = is_boss_wave and mega_boss is None
    normal_dead= not is_boss_wave and len(enemies)==0

                                    
    if boss_dead and wave == 10 and not boss_10_cleared and not boss_defeat_started:
        boss_10_cleared = True
                          
        bpos_x = MAP_W//2 - MEGA_SIZE//2
        bpos_y = MAP_H//2 - MEGA_SIZE//2
        start_boss_defeat_effect(bpos_x, bpos_y, ct)
        trigger_shake(20, 800)
                                        
        wave_clear = False
        pending_skill_show = False
        pygame.display.update()
        continue

    if not wave_clear and (boss_dead or normal_dead):
                                      
        if not (wave == 10 and is_boss_wave and boss_10_cleared):
            wave_clear=True; wave_clear_time=ct
            pending_skill_show=True; skill_show_time=ct+SKILL_SHOW_DELAY
            reset_boss_attack_state(); boss_bullets.clear()

    if pending_skill_show and ct>=skill_show_time:
        pending_skill_show=False; wave_clear=False
        choosing_skill=True; skill_choices=pick_choices()

           
    if not charging:
        mv_x=float(keys[pygame.K_d]-keys[pygame.K_a])
        mv_y=float(keys[pygame.K_s]-keys[pygame.K_w])
        mv_len=math.hypot(mv_x,mv_y)
        if mv_len>0: world_x-=mv_x/mv_len*player_speed; world_y-=mv_y/mv_len*player_speed
    else:
        charge_dist+=CHARGE_SPEED
        world_x-=math.cos(charge_angle)*CHARGE_SPEED
        world_y-=math.sin(charge_angle)*CHARGE_SPEED
        if charge_dist>=charge_max_dist: charging=False

    world_x=max(-(MAP_W-WIDTH//2),min(WIDTH//2,world_x))
    world_y=max(-(MAP_H-HEIGHT//2),min(HEIGHT//2,world_y))
    px=pwx(); py=pwy()

    def all_targets():
        t=list(enemies)
        if mega_boss: t.append(mega_boss)
        return t
    def esz(e):
        if e is mega_boss: return MEGA_SIZE
        if e[4]=="miniboss": return MINI_SIZE
        if e[4]=="fast": return FAST_SIZE
        return ENEMY_SIZE
    def ehitsz(e):
        if e is mega_boss: return BOSS_HIT_SIZE
        return esz(e)
    def ecx(e): return e[0]+esz(e)//2
    def ecy(e): return e[1]+esz(e)//2
    def hurt_enemy(e,dmg):
        global mega_boss
        actual_dmg=max(0.0,min(dmg,e[2]))
        if actual_dmg>0:
            now=pygame.time.get_ticks()
            existing=next((n for n in reversed(damage_numbers)
                           if n[4]==id(e) and now-n[3]<=150),None)
            if existing:
                existing[2]+=actual_dmg
                existing[3]=now
            else:
                damage_numbers.append([e[0]+esz(e)/2,e[1],actual_dmg,now,id(e)])
        e[2]-=dmg
        if e[2]<=0:
            if e is mega_boss: mega_boss=None
            elif e in enemies: enemies.remove(e)

    if sword_swinging:
        swing_progress=(ct-sword_swing_start)/SWORD_ANIM_DUR
        if swing_progress>=1.0: sword_swinging=False
        else:
            half_arc_r=math.radians(sword_arc/2)
            sword_visual_angle=(sword_swing_angle-half_arc_r)+2*half_arc_r*swing_progress
            for e in list(all_targets()):
                eid=id(e)
                if eid in sword_hit_ids: continue
                dx_e=ecx(e)-px; dy_e=ecy(e)-py; dist_e=math.hypot(dx_e,dy_e)
                if dist_e>sword_range+ehitsz(e)//2: continue
                diff=(math.atan2(dy_e,dx_e)-sword_swing_angle+math.pi)%(2*math.pi)-math.pi
                if abs(diff)<=half_arc_r:
                    hurt_enemy(e,sword_damage); sword_hit_ids.add(eid); trigger_shake(7,130)

    for pot in heal_potions[:]:
        if math.hypot(px-pot[0],py-pot[1])<P_SIZE//2+POTION_SIZE//2:
            player_hp=min(player_hp+POTION_HEAL,player_max_hp); heal_potions.remove(pot)

    if storm_active:
        elapsed_st=ct-storm_start_time
        storm_angle=(elapsed_st/STORM_DURATION)*4*math.pi
        sr=storm_radius(); sdmg=storm_dmg()
        for e in list(all_targets()):
            eid=id(e)
            if math.hypot(ecx(e)-px,ecy(e)-py)<sr+ehitsz(e)//2:
                next_t=storm_hit_timers.get(eid,0)
                if ct>=next_t:
                    hurt_enemy(e,sdmg); storm_hit_timers[eid]=ct+600; trigger_shake(3,60)

    for sl in slashes[:]:
        sl[3]+=SLASH_SPEED; sl[0]+=math.cos(sl[2])*SLASH_SPEED; sl[1]+=math.sin(sl[2])*SLASH_SPEED
        if sl[3]>=sl[4]: slashes.remove(sl); continue
        half_arc_sl=math.radians(60)
        for e in list(all_targets()):
            eid=id(e)
            if eid in sl[7]: continue
            dx_sl=ecx(e)-sl[0]; dy_sl=ecy(e)-sl[1]; dist_sl=math.hypot(dx_sl,dy_sl)
            if dist_sl>sl[6]+ehitsz(e)//2: continue
            diff_sl=(math.atan2(dy_sl,dx_sl)-sl[2]+math.pi)%(2*math.pi)-math.pi
            if abs(diff_sl)<=half_arc_sl:
                hurt_enemy(e,sl[5]); sl[7].add(eid); trigger_shake(8,130)

    if charging:
        for e in list(all_targets()):
            eid=id(e)
            if eid in charge_hit_ids: continue
            if math.hypot(ecx(e)-px,ecy(e)-py)<P_SIZE//2+ehitsz(e)//2+10:
                hurt_enemy(e,charge_dmg); charge_hit_ids.add(eid); trigger_shake(11,180)

    if mega_boss:
        bx_w=mega_boss[0]; by_w=mega_boss[1]
        bcx2=bx_w+MEGA_SIZE//2; bcy2=by_w+MEGA_SIZE//2
        phase=1 if mega_boss[2]<300 else 0; mega_boss[4]=phase
        is_20wave_boss=(wave>=20)
        beam_width=int(BEAM_WIDTH*(ENRAGE_BEAM_WIDTH_MULT if phase else 1.0))
        bomb_radius=int(BOMB_RADIUS*(ENRAGE_BOMB_RADIUS_MULT if phase else 1.0))
        wide_laser_range_mult=WIDE_LASER_RANGE_MULT*(ENRAGE_WIDE_LASER_RANGE_MULT if phase else 1.0)
        dx3=px-bcx2; dy3=py-bcy2; bdist=math.hypot(dx3,dy3)
        bspd=(1.5 if is_20wave_boss else 1.2)+phase*0.5
        if bdist>0: mega_boss[0]+=dx3/bdist*bspd; mega_boss[1]+=dy3/bdist*bspd

        if phase and not shielding and not charging:
            enrage_rect=pygame.Rect(bx_w-6,by_w-6,MEGA_SIZE+12,MEGA_SIZE+12)
            player_rect=pygame.Rect(px-P_SIZE//2,py-P_SIZE//2,P_SIZE,P_SIZE)
            if enrage_rect.colliderect(player_rect):
                damage_player(ENRAGE_BOSS_RECT_DMG*dt_ms/1000.0)

        boss_pattern_idle=(boss_beam_warning is None and not boss_beams and
                           boss_bomb_warning is None and boss_bomb_active is None and
                           boss_wide_laser_warning is None and boss_wide_laser_active is None)
        if boss_pattern_idle:
            boss_pattern_timer+=dt_ms
            if boss_pattern_timer>=BOSS_PATTERN_GAP:
                boss_pattern_timer=0
                cur_pattern=BOSS_PATTERN_ORDER[boss_pattern_idx%len(BOSS_PATTERN_ORDER)]
                boss_pattern_idx+=1
                if cur_pattern=="beam": boss_beam_warning=[bcx2,bcy2,boss_fire_angle,ct]
                elif cur_pattern=="bomb": boss_bomb_warning=[bcx2,bcy2,ct]
                else:
                    target_angle=math.atan2(py-bcy2,px-bcx2)
                    boss_wide_laser_warning=[bcx2,bcy2,target_angle,ct]

        if boss_beam_warning is not None and not boss_beams:
            if ct-boss_beam_warning[3]>=BEAM_WARNING_TIME:
                for di in range(6):
                    angle=boss_beam_warning[2]+math.radians(360/6*di)
                    boss_beams.append([bcx2,bcy2,angle,BEAM_ACTIVE_TIME])
                boss_beam_warning=None

        if boss_bomb_warning is not None and boss_bomb_active is None:
            if ct-boss_bomb_warning[2]>=BOMB_WARNING_TIME:
                boss_bomb_active=[bcx2,bcy2,ct,BOMB_ACTIVE_TIME]; boss_bomb_warning=None
        if boss_bomb_active is not None:
            if ct-boss_bomb_active[2]>=boss_bomb_active[3]: boss_bomb_active=None
            elif not shielding and not charging:
                dist_b=math.hypot(px-boss_bomb_active[0],py-boss_bomb_active[1])
                if abs(dist_b-bomb_radius)<=BOMB_WIDTH/2+P_SIZE/2:
                    damage_player(BOMB_DMG*dt_ms/1000.0)

        if boss_wide_laser_warning is not None and boss_wide_laser_active is None:
            if ct-boss_wide_laser_warning[3]>=BEAM_WARNING_TIME:
                boss_wide_laser_active=[bcx2,bcy2,boss_wide_laser_warning[2],
                                        BOSS_LASER_RANGE*wide_laser_range_mult,WIDE_LASER_WIDTH,WIDE_LASER_DURATION,ct]
                boss_wide_laser_warning=None
        if boss_wide_laser_active is not None and not shielding and not charging:
            if ct-boss_wide_laser_active[6]>=boss_wide_laser_active[5]: boss_wide_laser_active=None
            else:
                dx_w=px-boss_wide_laser_active[0]; dy_w=py-boss_wide_laser_active[1]
                proj_w=dx_w*math.cos(boss_wide_laser_active[2])+dy_w*math.sin(boss_wide_laser_active[2])
                perp_w=abs(dx_w*-math.sin(boss_wide_laser_active[2])+dy_w*math.cos(boss_wide_laser_active[2]))
                if 0<proj_w<boss_wide_laser_active[3] and perp_w<=boss_wide_laser_active[4]/2+P_SIZE/2:
                    damage_player(WIDE_LASER_DMG*dt_ms/1000.0)

        for beam in boss_beams[:]:
            beam[3]-=dt_ms
            if beam[3]<=0: boss_beams.remove(beam)
            elif not shielding and not charging:
                dx_bm=px-beam[0]; dy_bm=py-beam[1]
                proj_bm=dx_bm*math.cos(beam[2])+dy_bm*math.sin(beam[2])
                perp_bm=abs(dx_bm*-math.sin(beam[2])+dy_bm*math.cos(beam[2]))
                if 0<proj_bm<BOSS_LASER_RANGE and perp_bm<=beam_width/2+P_SIZE/2:
                    damage_player(BEAM_DMG*dt_ms/1000.0)

        boss_spawn_t+=dt_ms
        if boss_spawn_t>=ENRAGE_SPAWN_INTERVAL or boss_spawn_t>=BOSS_SPAWN_INT: boss_spawn_t=0

    pr3=pygame.Rect(px-P_SIZE//2,py-P_SIZE//2,P_SIZE,P_SIZE)
    for bb in boss_bullets[:]:
        bb[0]+=bb[2]; bb[1]+=bb[3]
        if bb[0]<0 or bb[0]>MAP_W or bb[1]<0 or bb[1]>MAP_H: boss_bullets.remove(bb); continue
        if not shielding and not charging:
            if pygame.Rect(bb[0]-6,bb[1]-6,12,12).colliderect(pr3):
                damage_player(BOSS_BULLET_DMG)
                if bb in boss_bullets: boss_bullets.remove(bb)

    for exp in boss_explosions[:]:
        if ct-exp[3]>500: boss_explosions.remove(exp)
        elif not shielding and not charging:
            if math.hypot(px-exp[0],py-exp[1])<exp[2]+P_SIZE//2:
                damage_player(EXPLOSION_DMG*(1.5 if phase==1 else 1.0))

    base_spd=2.0+wave*0.08
    for i,e in enumerate(enemies):
        sze=esz(e)
        spd=base_spd*2.3 if e[4]=="fast" else (base_spd*0.7 if e[4]=="miniboss" else base_spd)
        if e[5]>0: spd*=0.35
        dx4=px-ecx(e); dy4=py-ecy(e); d4=math.hypot(dx4,dy4)
        if d4>0: e[0]+=dx4/d4*spd; e[1]+=dy4/d4*spd
        for j,o in enumerate(enemies):
            if i==j: continue
            sep=(sze+esz(o))//2+2; sx4=e[0]-o[0]; sy4=e[1]-o[1]; sd4=math.hypot(sx4,sy4)
            if sd4<sep and sd4>0:
                push=(sep-sd4)/2; e[0]+=sx4/sd4*push; e[1]+=sy4/sd4*push
        if not shielding and not charging:
            if pygame.Rect(e[0],e[1],sze,sze).colliderect(pr3):
                enemy_id=id(e)
                if ct>=enemy_contact_attack_timers.get(enemy_id,0):
                    damage_player(5)
                    enemy_contact_attack_timers[enemy_id]=ct+2000

    if player_hp<=0: game_over=True

                                                                     
          
                                                                     
    screen.fill(GROUND_COL)
    ox=shake_ox; oy=shake_oy

    vis_x0=max(0,int((-world_x-ox)//GROUND_TILE)*GROUND_TILE-GROUND_TILE)
    vis_x1=min(MAP_W,vis_x0+WIDTH+GROUND_TILE*3)
    vis_y0=max(0,int((-world_y-oy)//GROUND_TILE)*GROUND_TILE-GROUND_TILE)
    vis_y1=min(MAP_H,vis_y0+HEIGHT+GROUND_TILE*3)

    for gx in range(vis_x0,vis_x1,GROUND_TILE):
        for gy in range(vis_y0,vis_y1,GROUND_TILE):
            stone_col=STONE_COL_A if (gx//GROUND_TILE+gy//GROUND_TILE)%2==0 else STONE_COL_B
            pygame.draw.rect(screen,stone_col,(gx+world_x+ox,gy+world_y+oy,GROUND_TILE,GROUND_TILE))
    for gx in range(vis_x0,vis_x1+GROUND_TILE,GROUND_TILE):
        pygame.draw.line(screen,GROUND_LINE,(gx+world_x+ox,vis_y0+world_y+oy),(gx+world_x+ox,vis_y1+world_y+oy))
    for gy in range(vis_y0,vis_y1+GROUND_TILE,GROUND_TILE):
        pygame.draw.line(screen,GROUND_LINE,(vis_x0+world_x+ox,gy+world_y+oy),(vis_x1+world_x+ox,gy+world_y+oy))

    for pot in heal_potions:
        pot_sx=int(pot[0]+world_x+ox); pot_sy=int(pot[1]+world_y+oy)
        if -POTION_SIZE<=pot_sx<=WIDTH+POTION_SIZE and -POTION_SIZE<=pot_sy<=HEIGHT+POTION_SIZE:
            pygame.draw.circle(screen,(20,80,40),(pot_sx,pot_sy),POTION_SIZE)
            pygame.draw.circle(screen,POTION_COL,(pot_sx,pot_sy),POTION_SIZE,3)
            cs=POTION_SIZE-6
            pygame.draw.rect(screen,WHITE,(pot_sx-3,pot_sy-cs,6,cs*2))
            pygame.draw.rect(screen,WHITE,(pot_sx-cs,pot_sy-3,cs*2,6))
            ht=font_card_s.render(f"+{POTION_HEAL}",True,POTION_COL)
            screen.blit(ht,(pot_sx-ht.get_width()//2,pot_sy+POTION_SIZE+2))
            ga=int(abs(math.sin(ct*0.004))*120)
            gs=pygame.Surface((POTION_SIZE*4,POTION_SIZE*4),pygame.SRCALPHA)
            pygame.draw.circle(gs,(*POTION_COL,ga),(POTION_SIZE*2,POTION_SIZE*2),POTION_SIZE*2)
            screen.blit(gs,(pot_sx-POTION_SIZE*2,pot_sy-POTION_SIZE*2))

    boss_enraged=bool(mega_boss and mega_boss[4])
    draw_beam_width=int(BEAM_WIDTH*(ENRAGE_BEAM_WIDTH_MULT if boss_enraged else 1.0))
    draw_bomb_radius=int(BOMB_RADIUS*(ENRAGE_BOMB_RADIUS_MULT if boss_enraged else 1.0))
    draw_wide_laser_range_mult=WIDE_LASER_RANGE_MULT*(ENRAGE_WIDE_LASER_RANGE_MULT if boss_enraged else 1.0)

    if boss_beam_warning is not None:
        bx2=int(boss_beam_warning[0]+world_x+ox); by2=int(boss_beam_warning[1]+world_y+oy)
        warn_age=ct-boss_beam_warning[3]
        alpha=int(200*min(1.0,max(0.0,1.0-warn_age/BEAM_WARNING_TIME)))
        warn_surf=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        for di in range(6):
            angle=boss_beam_warning[2]+math.radians(360/6*di)
            ex2=int(bx2+math.cos(angle)*BOSS_LASER_RANGE); ey2=int(by2+math.sin(angle)*BOSS_LASER_RANGE)
            pygame.draw.line(warn_surf,(255,180,50,alpha),(bx2,by2),(ex2,ey2),max(4,draw_beam_width//4))
        pygame.draw.circle(warn_surf,(255,220,60,alpha),(bx2,by2),18,3)
        screen.blit(warn_surf,(0,0))

    for beam in boss_beams:
        bx2=int(beam[0]+world_x+ox); by2=int(beam[1]+world_y+oy); angle=beam[2]
        ex2=int(bx2+math.cos(angle)*BOSS_LASER_RANGE); ey2=int(by2+math.sin(angle)*BOSS_LASER_RANGE)
        beam_surf=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        pygame.draw.line(beam_surf,(255,80,40,180),(bx2,by2),(ex2,ey2),draw_beam_width)
        pygame.draw.line(beam_surf,(255,210,150,220),(bx2,by2),(ex2,ey2),6)
        screen.blit(beam_surf,(0,0))

    if boss_bomb_warning is not None:
        bx2=int(boss_bomb_warning[0]+world_x+ox); by2=int(boss_bomb_warning[1]+world_y+oy)
        warn_age=ct-boss_bomb_warning[2]
        alpha=int(220*min(1.0,max(0.0,warn_age/BOMB_WARNING_TIME)))
        pygame.draw.circle(screen,(255,140,40,alpha),(bx2,by2),draw_bomb_radius,4)
        pygame.draw.circle(screen,(255,220,100,alpha),(bx2,by2),draw_bomb_radius//2,2)

    if boss_bomb_active is not None:
        bx2=int(boss_bomb_active[0]+world_x+ox); by2=int(boss_bomb_active[1]+world_y+oy)
        progress=min(1.0,(ct-boss_bomb_active[2])/boss_bomb_active[3])
        pygame.draw.circle(screen,(255,100,0,int(200*(1.0-progress))),(bx2,by2),draw_bomb_radius,int(BOMB_WIDTH+progress*20))
        pygame.draw.circle(screen,(255,220,120,int(200*(1.0-progress))),(bx2,by2),draw_bomb_radius//2,3)

    if boss_wide_laser_warning is not None:
        bx2=int(boss_wide_laser_warning[0]+world_x+ox); by2=int(boss_wide_laser_warning[1]+world_y+oy)
        warn_age=ct-boss_wide_laser_warning[3]
        alpha=int(200*min(1.0,max(0.0,warn_age/BEAM_WARNING_TIME))); angle=boss_wide_laser_warning[2]
        ex2=int(bx2+math.cos(angle)*BOSS_LASER_RANGE*draw_wide_laser_range_mult); ey2=int(by2+math.sin(angle)*BOSS_LASER_RANGE*draw_wide_laser_range_mult)
        warn_surf=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        pygame.draw.line(warn_surf,(255,220,0,alpha),(bx2,by2),(ex2,ey2),WIDE_LASER_WIDTH//2)
        pygame.draw.circle(warn_surf,(255,220,0,alpha),(bx2,by2),18,3)
        screen.blit(warn_surf,(0,0))

    if boss_wide_laser_active is not None:
        bx2=int(boss_wide_laser_active[0]+world_x+ox); by2=int(boss_wide_laser_active[1]+world_y+oy)
        angle=boss_wide_laser_active[2]
        ex2=int(bx2+math.cos(angle)*boss_wide_laser_active[3]); ey2=int(by2+math.sin(angle)*boss_wide_laser_active[3])
        laser_surf=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        pygame.draw.line(laser_surf,(255,80,80,180),(bx2,by2),(ex2,ey2),boss_wide_laser_active[4])
        pygame.draw.line(laser_surf,(255,180,120,200),(bx2,by2),(ex2,ey2),boss_wide_laser_active[4]//2)
        screen.blit(laser_surf,(0,0))

    for sl in slashes:
        sl_sx=int(sl[0]+world_x+ox); sl_sy=int(sl[1]+world_y+oy)
        prog_sl=sl[3]/sl[4]; alpha_sl=int(220*(1.0-prog_sl)); half_arc_sl=math.radians(60)
        sl_surf=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        arc_pts=[(sl_sx,sl_sy)]
        for si in range(25):
            frac=si/24; a_cur=sl[2]-half_arc_sl+2*half_arc_sl*frac
            arc_pts.append((sl_sx+math.cos(a_cur)*sl[6],sl_sy+math.sin(a_cur)*sl[6]))
        if len(arc_pts)>=3:
            pygame.draw.polygon(sl_surf,(180,255,200,alpha_sl//3),arc_pts)
            pygame.draw.polygon(sl_surf,(220,255,230,alpha_sl),arc_pts,3)
        screen.blit(sl_surf,(0,0))

    if storm_active:
        elapsed_st2=ct-storm_start_time; prog_st=elapsed_st2/STORM_DURATION
        sr=storm_radius(); alpha_st=int(210*(1.0-prog_st*0.4))
        st_surf=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        cx_st=PLAYER_SCR_CX+ox; cy_st=PLAYER_SCR_CY+oy
        pygame.draw.circle(st_surf,(80,180,255,alpha_st//5),(cx_st,cy_st),sr)
        for layer in range(3):
            base_off=storm_angle+math.radians(120*layer)
            arc_pts_out=[]
            for si in range(31):
                frac=si/30; ang=base_off+math.radians(100)*frac
                arc_pts_out.append((cx_st+math.cos(ang)*sr,cy_st+math.sin(ang)*sr))
            cols=[(80,200,255),(160,230,255),(220,245,255)]
            if len(arc_pts_out)>=2:
                pygame.draw.lines(st_surf,(*cols[layer],alpha_st),False,arc_pts_out,8)
                pygame.draw.lines(st_surf,(255,255,255,alpha_st//2),False,arc_pts_out,2)
            tip_x=int(cx_st+math.cos(base_off)*sr); tip_y=int(cy_st+math.sin(base_off)*sr)
            pygame.draw.circle(st_surf,(255,255,255,alpha_st),(tip_x,tip_y),5)
            pygame.draw.circle(st_surf,(*cols[layer],alpha_st),(tip_x,tip_y),9,2)
        pygame.draw.circle(st_surf,(120,200,255,alpha_st//2),(cx_st,cy_st),sr,2)
        pygame.draw.circle(st_surf,(180,230,255,alpha_st//3),(cx_st,cy_st),max(1,sr-12),1)
        screen.blit(st_surf,(0,0))

    if charging:
        ch_prog=charge_dist/charge_max_dist; cx_ch=PLAYER_SCR_CX+ox; cy_ch=PLAYER_SCR_CY+oy
        ch_surf=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        for ti,(trail_l,trail_w,trail_a) in enumerate([(90,28,60),(70,20,100),(50,12,160),(30,6,220)]):
            tx=int(cx_ch-math.cos(charge_angle)*trail_l); ty=int(cy_ch-math.sin(charge_angle)*trail_l)
            pygame.draw.line(ch_surf,(255,140+ti*20,30+ti*15,trail_a),(cx_ch,cy_ch),(tx,ty),trail_w)
        shock_r=int(30+ch_prog*20)
        shock_x=int(cx_ch+math.cos(charge_angle)*(P_SIZE//2+shock_r//2))
        shock_y=int(cy_ch+math.sin(charge_angle)*(P_SIZE//2+shock_r//2))
        pygame.draw.circle(ch_surf,(255,220,80,180),(shock_x,shock_y),shock_r,4)
        pygame.draw.circle(ch_surf,(255,255,200,80),(shock_x,shock_y),shock_r+6,2)
        perp_x=-math.sin(charge_angle); perp_y=math.cos(charge_angle)
        for side in [-1,1]:
            for spark_i in range(4):
                spark_dist=15+spark_i*12; spark_len=20+spark_i*8
                spx=cx_ch+side*perp_x*spark_dist-math.cos(charge_angle)*spark_i*10
                spy=cy_ch+side*perp_y*spark_dist-math.sin(charge_angle)*spark_i*10
                pygame.draw.line(ch_surf,(255,200,80,max(0,200-spark_i*40)),
                                 (int(spx),int(spy)),(int(spx+side*perp_x*spark_len),int(spy+side*perp_y*spark_len)),2)
        screen.blit(ch_surf,(0,0))
        flash_alpha=int(60*(1.0-ch_prog))
        if flash_alpha>0:
            flash_s=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); flash_s.fill((255,180,40,flash_alpha)); screen.blit(flash_s,(0,0))

    if sword_swinging:
        progress=(ct-sword_swing_start)/SWORD_ANIM_DUR; half_arc_r=math.radians(sword_arc/2)
        arc_surf=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); alpha_sw=int(200*(1.0-progress))
        pcx_s=PLAYER_SCR_CX+ox; pcy_s=PLAYER_SCR_CY+oy
        arc_pts=[(pcx_s,pcy_s)]
        for si in range(21):
            frac=si/20; a_cur=sword_swing_angle-half_arc_r+2*half_arc_r*frac
            arc_pts.append((pcx_s+math.cos(a_cur)*sword_range,pcy_s+math.sin(a_cur)*sword_range))
        if len(arc_pts)>=3:
            pygame.draw.polygon(arc_surf,(*SWORD_COL,alpha_sw//3),arc_pts)
            pygame.draw.polygon(arc_surf,(*SWORD_COL,alpha_sw),arc_pts,2)
        screen.blit(arc_surf,(0,0))
        tip_x=pcx_s+math.cos(sword_visual_angle)*sword_range; tip_y=pcy_s+math.sin(sword_visual_angle)*sword_range
        pygame.draw.line(screen,WHITE,(pcx_s,pcy_s),(int(tip_x),int(tip_y)),4)
        pygame.draw.circle(screen,SWORD_COL,(int(tip_x),int(tip_y)),6)
        hilt_x=int(pcx_s+math.cos(sword_visual_angle)*18); hilt_y=int(pcy_s+math.sin(sword_visual_angle)*18)
        pygame.draw.circle(screen,GOLD,(hilt_x,hilt_y),5)

    for e in enemies:
        sze=esz(e); ex5=int(e[0]+world_x+ox); ey5=int(e[1]+world_y+oy)
        img=MINI_ENEMY_IMG if e[4]=="miniboss" else (FAST_ENEMY_IMG if e[4]=="fast" else NORMAL_ENEMY_IMG)
        screen.blit(img,(ex5,ey5))
        pygame.draw.rect(screen,(80,0,0),(ex5,ey5-12,sze,7))
        pygame.draw.rect(screen,GREEN,(ex5,ey5-12,int(sze*max(e[2],0)/e[3]),7))

    if mega_boss:
        bsx3=int(mega_boss[0]+world_x+ox); bsy3=int(mega_boss[1]+world_y+oy)
        ph=mega_boss[4]; is_20w=(wave>=20)
        if ph:
            pulse=abs(math.sin(ct*0.005))*60
            gs2=pygame.Surface((MEGA_SIZE+24,MEGA_SIZE+24),pygame.SRCALPHA); gs2.fill((255,int(pulse),int(pulse),60))
            screen.blit(gs2,(bsx3-12,bsy3-12))
        screen.blit(BOSS_IMG,(bsx3,bsy3))
        if is_20w:
            li2=font_card_s.render("Laser",True,YELLOW); screen.blit(li2,(bsx3,bsy3+MEGA_SIZE-30))
        bw3=WIDTH//2; bh3=28; bxb=(WIDTH-bw3)//2; byb=HEIGHT-70
        ratio3=max(0,mega_boss[2]/mega_boss[3])
        bcol3=(255,80,80) if ph else ((220,20,20) if is_20w else (220,20,220))
        bc3=(255,80,80) if is_20w else BOSS_BORDER
        pygame.draw.rect(screen,(60,0,60),(bxb,byb,bw3,bh3),border_radius=6)
        pygame.draw.rect(screen,bcol3,(bxb,byb,int(bw3*ratio3),bh3),border_radius=6)
        pygame.draw.rect(screen,bc3,(bxb,byb,bw3,bh3),2,border_radius=6)
        bl3=font_boss.render(f"{'[ENRAGED] ' if ph else ''}{'[ELITE BOSS] ' if is_20w else ''}BOSS  {max(0,int(mega_boss[2]))} / {int(mega_boss[3])}",True,RED if ph else bc3)
        screen.blit(bl3,(WIDTH//2-bl3.get_width()//2,byb-42))
        pygame.draw.rect(screen,(80,0,0),(bsx3,bsy3-16,MEGA_SIZE,10))
        pygame.draw.rect(screen,bcol3,(bsx3,bsy3-16,int(MEGA_SIZE*ratio3),10))
        if ph:
            warn=font_card_d.render(f"!! ENRAGED - FAST {enrage_fast_spawned}/{ENRAGE_MAX_FAST} / NORMAL {enrage_normal_spawned}/{ENRAGE_MAX_NORMAL} !!",True,RED)
            screen.blit(warn,(WIDTH//2-warn.get_width()//2,byb-72))

    damage_numbers[:]=[n for n in damage_numbers if ct-n[3]<850]
    for nx,ny,amount,started,_ in damage_numbers:
        age=ct-started
        label=font_card_d.render(f"-{max(1,round(amount))}",True,YELLOW)
        label.set_alpha(max(0,255-int(255*age/850)))
        screen.blit(label,(int(nx+world_x+ox-label.get_width()/2),
                           int(ny+world_y+oy-28-age*0.045)))

    for bb2 in boss_bullets:
        bx4=int(bb2[0]+world_x+ox); by4=int(bb2[1]+world_y+oy)
        col_bb=(255,40,40) if wave>=20 else (255,60,200)
        pygame.draw.circle(screen,col_bb,(bx4,by4),7); pygame.draw.circle(screen,WHITE,(bx4,by4),7,2)

    for warn in boss_explosion_warnings:
        ex_scr=int(warn[0]+world_x+ox); ey_scr=int(warn[1]+world_y+oy)
        warn_age=ct-warn[3]
        if int(warn_age*10)%2==0:
            pygame.draw.circle(screen,(255,200,0),(ex_scr,ey_scr),int(warn[2]),3)
            pygame.draw.circle(screen,(255,150,0,int(255*(1.0-warn_age/EXPLOSION_WARNING_TIME))),(ex_scr,ey_scr),int(warn[2])//2,2)

    for exp in boss_explosions:
        ex_scr=int(exp[0]+world_x+ox); ey_scr=int(exp[1]+world_y+oy); exp_radius=int(exp[2])
        col_exp=(255,100,50) if wave>=20 else (255,140,80)
        pygame.draw.circle(screen,col_exp,(ex_scr,ey_scr),exp_radius,4)
        pygame.draw.circle(screen,(255,200,100),(ex_scr,ey_scr),exp_radius//3)

    if not sword_swinging:
        aim_angle=math.atan2(my-PLAYER_SCR_CY,mx-PLAYER_SCR_CX)
        cd_ratio=min(1.0,(ct-last_sword_time)/max(sword_cooldown,1))
        aim_col=SWORD_COL if cd_ratio>=1.0 else (100,130,160)
        pygame.draw.line(screen,(*aim_col,120),(PLAYER_SCR_CX+ox,PLAYER_SCR_CY+oy),
                         (int(PLAYER_SCR_CX+ox+math.cos(aim_angle)*sword_range),
                          int(PLAYER_SCR_CY+oy+math.sin(aim_angle)*sword_range)),2)

    if shielding:
        sp=(ct-shield_start_time)/SHIELD_DURATION; sa=int(180*(1.0-sp*0.5))
        sh_s=pygame.Surface((P_SIZE+30,P_SIZE+30),pygame.SRCALPHA)
        pygame.draw.circle(sh_s,(*SHIELD_COL,sa),((P_SIZE+30)//2,(P_SIZE+30)//2),(P_SIZE+30)//2)
        screen.blit(sh_s,(player_x+ox-15,player_y+oy-15))
        pygame.draw.circle(screen,SHIELD_COL,(PLAYER_SCR_CX+ox,PLAYER_SCR_CY+oy),P_SIZE//2+12,3)

    sp_w,sp_h=PLAYER_SPRITE.get_size()
    sp_x=player_x+ox+P_SIZE//2-sp_w//2; sp_y=player_y+oy+P_SIZE-sp_h+6
    screen.blit(PLAYER_SPRITE,(sp_x,sp_y))
    player_damage_numbers[:]=[n for n in player_damage_numbers if ct-n[1]<850]
    for amount,started in player_damage_numbers:
        age=ct-started
        label=font_card_d.render(f"-{max(1,round(amount))}",True,RED)
        label.set_alpha(max(0,255-int(255*age/850)))
        screen.blit(label,(PLAYER_SCR_CX+ox-label.get_width()//2,
                           sp_y-30-int(age*0.045)))
    if charging:
        ch_s=pygame.Surface((sp_w,sp_h),pygame.SRCALPHA); ch_s.fill((255,160,40,140)); screen.blit(ch_s,(sp_x,sp_y))
    hp_bar_x=player_x+ox
    hp_bar_y=sp_y-12
    pygame.draw.rect(screen,(80,0,0),(hp_bar_x,hp_bar_y,P_SIZE,6))
    pygame.draw.rect(screen,GREEN,(hp_bar_x,hp_bar_y,int(P_SIZE*max(player_hp,0)/player_max_hp),6))

            
    screen.blit(font_hud.render(f"HP: {max(int(player_hp),0)} / {player_max_hp}",True,WHITE),(50,50))
    pygame.draw.rect(screen,(80,0,0),(50,92,220,16))
    pygame.draw.rect(screen,GREEN,(50,92,int(220*max(player_hp,0)/player_max_hp),16))
    wlabel="  * BOSS WAVE *" if is_boss_wave else f"  {wave} WAVE"
    screen.blit(font_hud.render(wlabel,True,RED if is_boss_wave else GOLD),(WIDTH-font_hud.size(wlabel)[0]-30,50))
    if not is_boss_wave:
        et=font_hud.render(f"Enemies: {len(enemies)}",True,WHITE)
        screen.blit(et,(WIDTH-et.get_width()-30,95))
        nw=((wave//3)+1)*3
        pi2=font_card_s.render("Health potion appeared!" if (wave%3==0 and heal_potions) else f"Health potion in: {nw-wave} waves",
                               True,POTION_COL if (wave%3==0 and heal_potions) else (150,200,150))
        screen.blit(pi2,(50,115))

    draw_minimap()

    hud_base_y=HEIGHT-165
    sw_r=min(1.0,(ct-last_sword_time)/max(sword_cooldown,1)); sw_rdy=sw_r>=1.0
    pygame.draw.rect(screen,(40,40,40),(50,hud_base_y,160,16),border_radius=4)
    pygame.draw.rect(screen,SWORD_COL if sw_rdy else (80,110,140),(50,hud_base_y,int(160*sw_r),16),border_radius=4)
    screen.blit(font_card_s.render("Sword Ready!" if sw_rdy else f"Sword {max(0,(sword_cooldown-(ct-last_sword_time))//1000+1)} sec.",True,WHITE),(220,hud_base_y))

    if has("shield"):
        sh_y=hud_base_y+27; sh_r=min(1.0,(ct-last_shield_time)/shield_cooldown); sh_rdy=sh_r>=1.0 and not shielding
        pygame.draw.rect(screen,(40,40,40),(50,sh_y,160,14))
        fw=int(160*(1.0-(ct-shield_start_time)/SHIELD_DURATION)) if shielding else int(160*sh_r)
        pygame.draw.rect(screen,(150,220,255) if shielding else (SHIELD_COL if sh_rdy else (40,80,140)),(50,sh_y,fw,14))
        screen.blit(font_card_s.render("Shield Active!" if shielding else ("Shield Ready!" if sh_rdy else f"Shield {max(0,(shield_cooldown-(ct-last_shield_time))//1000+1)} sec."),
                                       True,WHITE if (sh_rdy or shielding) else (150,150,150)),(220,sh_y))

    active_skill_hud=[
        ("storm_atk","Storm [E]",(160,220,255),last_storm_time,storm_cooldown,storm_active),
        ("slash_wave","Slash [R]",(200,255,180),last_slash_time,slash_cooldown,False),
        ("charge_atk","Charge [F]",(255,180,80),last_charge_time,charge_cooldown,charging),
    ]
    skill_hud_start=hud_base_y+27+(27 if has("shield") else 0)
    for sid,label,col,last_t,cd,is_active in active_skill_hud:
        if not has(sid): continue
        ratio_h=min(1.0,(ct-last_t)/max(cd,1)); rdy=ratio_h>=1.0 and not is_active
        pygame.draw.rect(screen,(40,40,40),(50,skill_hud_start,160,12),border_radius=3)
        pygame.draw.rect(screen,(100,255,200) if is_active else (col if rdy else (60,80,80)),(50,skill_hud_start,int(160*ratio_h),12),border_radius=3)
        txt=label+(" Active!" if is_active else (" Ready!" if rdy else f" {max(0,(cd-(ct-last_t))//1000+1)} sec."))
        screen.blit(font_card_s.render(txt,True,WHITE if rdy or is_active else (140,140,140)),(220,skill_hud_start))
        skill_hud_start+=27

    if acquired:
        sk_str="  /  ".join(f"{SKILL_MAP[sid]['name']} Lv{lv}" for sid,lv in acquired.items())
        screen.blit(font_card_s.render("Skills: "+sk_str,True,CYAN),(50,HEIGHT-35))

    if showing_banner:
        eb=ct-wave_start_time
        if eb<wave_banner_dur:
            a2=max(0,255-int(255*eb/wave_banner_dur))
            label2="* BOSS WAVE! *" if is_boss_wave else f"{wave} WAVE"
            bs5=font_banner.render(label2,True,RED if is_boss_wave else GOLD); bs5.set_alpha(a2)
            screen.blit(bs5,(WIDTH//2-bs5.get_width()//2,HEIGHT//2-70))
        else: showing_banner=False

    if pending_skill_show:
        remain=max(0,skill_show_time-ct)
        wait_txt=font_card_d.render(f"Choose a skill in... {remain//1000+1} sec.",True,GOLD)
        wait_txt.set_alpha(180)
        screen.blit(wait_txt,(WIDTH//2-wait_txt.get_width()//2,HEIGHT//2+60))

    if not game_over and not choosing_skill:
        draw_pause_button(mx, my)

    pygame.display.update()

pygame.quit()
sys.exit()
